# KEEP ALIVE EXAMPLE

<!-- DOCS-IGNORE:start -->
<!-- ALL-CONTRIBUTORS-BADGE:START - Do not remove or modify this section -->

[![All Contributors](https://img.shields.io/badge/all_contributors-2-orange.svg?style=flat-square)](#contributors-)

<!-- ALL-CONTRIBUTORS-BADGE:END -->
<!-- DOCS-IGNORE:end -->

⚠️ App not published ⚠️

This `template` let's you define endpoints, either REST or GRAPHQL, that will be periodically called to prevent the time to live (TTL) from triggering and setting the app to sleep.

This action is fired by a PIXEL script tag that only runs 1 time a day per customer.

## Configuration

1. Download the template and adjust the code to your specifications
2. Publish and install it
3. The app will then appear in '/admin/apps/', you'll need to configure your endpoints accordingly

<!-- DOCS-IGNORE:start -->

## Contributors

Thanks goes to these wonderful people:

<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<!-- markdownlint-enable -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->

This project follows the [all-contributors](https://github.com/all-contributors/all-contributors) specification. Contributions of any kind are welcome!

<!-- DOCS-IGNORE:end -->
