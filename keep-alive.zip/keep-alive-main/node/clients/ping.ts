import type { InstanceOptions, IOContext } from '@vtex/api'
import { ExternalClient } from '@vtex/api'

export default class Ping extends ExternalClient {
  constructor(ctx: IOContext, options?: InstanceOptions) {
    super('', ctx, {
      ...options,
      headers: {
        ...options?.headers,
        VtexIdClientAutCookie: ctx.authToken,
      },
    })
  }


    public async rest(endpoint: string): Promise<void> {
      console.log("https://pagonxtpartner.myvtex.com" + endpoint);
  
      return this.http.post(
        "https://pagonxtpartner.myvtex.com" + endpoint
      )
    }

  public async graphql(
    vendor: string,
    name: string,
    version: string
  ): Promise<void> {
    return this.http.get(
      `http://app.io.vtex.com/${vendor}.${name}/v${version}/${this.context.account}/${this.context.workspace}/_v/graphql`
    )
  }
}
