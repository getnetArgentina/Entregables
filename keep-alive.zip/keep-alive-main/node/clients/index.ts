import { IOClients } from '@vtex/api'

import Ping from './ping'

export class Clients extends IOClients {
  public get ping() {
    return this.getOrSet('ping', Ping)
  }
}
