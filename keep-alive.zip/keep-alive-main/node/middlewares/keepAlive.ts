import { ResolverError } from '@vtex/api'

import { pingEndpoints } from './utils/pingEndpoints'

export async function keepAlive(ctx: Context, next: () => Promise<any>) {
  const {
    clients: { apps, ping },
  } = ctx

  const { endpoints } = await apps.getAppSettings(
    process.env.VTEX_APP_ID as string
  )

  if (!endpoints?.length) {
    throw new ResolverError('No defined endpoints to keep alive')
  }

  pingEndpoints(ping, endpoints)

  ctx.status = 200
  ctx.set('Cache-Control', 'no-cache')

  await next()
}
