import type ping from '../../clients/ping'

interface Endpoint {
  endpoint: RestAPI | GraphqlAPI
}

interface RestAPI {
  pathName: string
}

interface GraphqlAPI {
  vendor: string
  name: string
  version: string
}

export async function pingEndpoints(client: ping, endpoints: Endpoint[]) {
  const { rest, graphql } = client

  await Promise.allSettled(
    endpoints.map(({ endpoint }) => {
      if ('pathName' in endpoint) {
        return rest(endpoint.pathName)
      }

      const { vendor, name, version } = endpoint

      return graphql(vendor, name, version)
    })
  )
}
