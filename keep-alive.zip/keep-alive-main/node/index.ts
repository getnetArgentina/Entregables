import type { ClientsConfig, ServiceContext } from '@vtex/api'
import { LRUCache, method, Service } from '@vtex/api'

import { Clients } from './clients'
import { keepAlive } from './middlewares/keepAlive'

const TIMEOUT_MS = 800
const memoryCache = new LRUCache<string, any>({ max: 5000 })

metrics.trackCache('keepAlive', memoryCache)

const clients: ClientsConfig<Clients> = {
  implementation: Clients,
  options: {
    default: {
      retries: 2,
      timeout: TIMEOUT_MS,
    },
    keepAlive: {
      memoryCache,
    },
  },
}

declare global {
  type Context = ServiceContext<Clients>
}

export default new Service({
  clients,
  routes: {
    keep_alive: method({
      GET: [keepAlive],
    }),
  },
})
