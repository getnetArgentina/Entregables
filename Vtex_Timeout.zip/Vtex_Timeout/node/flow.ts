import {
  Authorizations,
  Cancellations,
  Refunds,
  CardAuthorization,
  CancellationRequest,
  RefundRequest,
} from '@vtex/payment-provider'

import { IOContext, InstanceOptions } from '@vtex/api';

import { clientGetnet } from './clientGetnetWS'

import { getToken, Cancel, Refund} from './clientGetnetWS'

import { randomString } from './utils'


export const testAuthorization = async (
  request: CardAuthorization
): Promise<any> => {
    return Authorizations.approve(request, {
      authorizationId: randomString(),
      nsu: randomString(),
      message:' ',
      tid: randomString(),
    })
}



export const getnetPayment = async (
  request: CardAuthorization,  dataHeader: any, contextIO: IOContext
): Promise<any> => {
  
  console.log("----------------------------------------------------------------");
    console.log("-- -- -- Init Payment provider-- -- --");

    const opciones: InstanceOptions = {
      headers: {
        'X-VTEX-Use-Https': 'true',
      },
      retries: 3,
    };

    try {

      const merchantSettingsArray = request.merchantSettings;
      let plan;

      if (merchantSettingsArray) {
          merchantSettingsArray.forEach(setting => {
            const name = setting.name;
            const value = setting.value;

            if(name == 'Planes'){
              plan = value;
              console.log(plan);
            }

          });
      }     

      let tokenRes =  await getToken(dataHeader);

      const clienteGetnet = new clientGetnet(contextIO, opciones);

      let tokenCardID =  await clienteGetnet.Tokenize(tokenRes, request, dataHeader);

      let resultado =  await clienteGetnet.paymentWS(tokenCardID, request, dataHeader, tokenRes, plan);
      
      const paymentResponse = JSON.stringify(resultado);
      console.log("respuesta WS payment - " + paymentResponse);
      console.log(resultado.status);

      
      if(resultado.status = "Authorized"){
        console.log("Pago aprobado --> authorization_code: " + resultado.authorization_code);
        
        return Authorizations.approve(request, {
                authorizationId: resultado.authorization_code,
                acquirer: 'Getnet',
                nsu: resultado.payment_id,
                tid: resultado.payment_id,
            })

      } else {
        console.log("Pago Denegado");
          return Authorizations.deny(request, { tid: randomString(), message: "Payment Denied" })
      }
    
  } catch (error) {
      console.log(error);
      return Authorizations.deny(request, { tid: randomString(), message: "Payment Denied" })
  }

}




export const getnetCancel = async (
  cancellation: CancellationRequest,  dataHeader: any
): Promise<any> => {

  console.log("-- -- -- Cancel -- -- --");

  let tokenRes =  await getToken(dataHeader);
  console.log("tokenRes --> " + tokenRes);

  let result =  await Cancel(tokenRes, dataHeader, cancellation);

  if(result.status == "Cancelled"){
    return Cancellations.approve(cancellation, {
            cancellationId: cancellation.paymentId,
            code: result.authorization_code,
          })
  } else {
      return Cancellations.deny(cancellation, { message: "Not Cancelled" })
  }

}



export const getnetRefund = async (
  refund: RefundRequest,  dataHeader: any
): Promise<any> => {

  console.log("-- -- -- Refund -- -- --");

  let tokenRes =  await getToken(dataHeader);
  console.log("tokenRes --> " + tokenRes);

  let result =  await Refund(tokenRes, dataHeader, refund);

  if(result.status == "Refunded"){
    return Refunds.approve(refund, {
        refundId: refund.paymentId,
            code: result.authorization_code,
          })
  } else {
      return Refunds.deny(refund, { message: "Not Refunded" })
  }

}



export function generateAuth(): string {
  // en primera fase se simulara este dato, despues se habilitara la autorizacion en 2 pasos
  const randomNumber = Math.floor(Math.random() * (99999999 - 10000000 + 1)) + 10000000 + "";
  return randomNumber;
}