import axios from 'axios';
import { SecureExternalClient } from '@vtex/payment-provider';
import { URLSearchParams } from "url"
import { IOContext, InstanceOptions } from '@vtex/api';


export class clientGetnet extends SecureExternalClient {
  constructor(protected context: IOContext, options?:InstanceOptions | undefined){
  super('https://api.pre.globalgetnet.com', context, options);
  }


  /**
   * 
   * @param token 
   * @param request 
   * @param data 
   * @returns 
   */
  async Tokenize(token: any, request: any, data: any): Promise<any> {
   
    console.log(" ");
    console.log("----------------------------------------------------------------");
    console.log("-------- Tokenizamos la tarjeta paso 2  (Security Proxy)---------------")

    try {

      let Year = request.card.expiration.year
      const brand = getBrandCard(request.card.bin);

      if(request.card.expiration.year.length == 4){
        Year = Year.substring(2, 4)
      }

      console.log("Brand " + brand);

      let body = {
        "method_type": "card",
        "card_pan": request.card.numberToken, //request.card.number,
        "brand": brand,
        "cardholder_name": request.card.holderToken,  //request.card.holder,
        "expiration_month": request.card.expiration.month,
        "expiration_year": Year
      };

      const response = await axios.post(request.secureProxyUrl, body, {
        headers: {
          'X-Vtex-Use-Https': 'true',
          'Proxy-Authorization': data.authToken,
          'X-PROVIDER-Forward-Content-Type': 'application/json',
          'X-PROVIDER-Forward-Authorization': 'Bearer ' + token,
          'X-PROVIDER-Forward-To' : 'https://api.pre.globalgetnet.com/checkout/v1/tokens'
        },
      });

      const resp = response.data

      const paymentResponse = JSON.stringify(resp);
      console.log("respuesta WS tokenize - " + paymentResponse);

      return resp.token_id;

    } catch (error) {
      console.log(`Error al enviar la solicitud POST: ${error}`);
      return "error";
    }
  }




  /**
   * 
   * @param tokenID 
   * @param request 
   * @param data 
   * @param token 
   * @returns 
   */
  async paymentWS(tokenID: any, request: any, data: any, token: any, plan: any): Promise<any> {

    let  planes;
    
    if(plan == 'planA'){
      planes = 'plan_ahora'
    } else {
      planes = 'plan_emisor';
    }

    try {

      let typePlan = "no_interest";
      let interest_rate: number = request.installmentsInterestRate;

      const currency = request.currency.replace("ARG", "ARS");

      const countryShipping = getCountryCode(request.miniCart.shippingAddress?.country);
      const countryBilling = getCountryCode(request.miniCart.billingAddress?.country);

      const name = request.miniCart.buyer.firstName + " " + request.miniCart.buyer.lastName;

      let installmentOptions =  await installmentQuote(request, typePlan, data.authToken, token, planes);

      if(request.installmentsInterestRate !== 0){
        typePlan = "with_interest";
        interest_rate = parseInt(request.installmentsInterestRate, 10);
      }

      console.log("installmentOptions.interest_rate GETNET: " + installmentOptions.interest_rate);
      console.log("interest_rate --> " + interest_rate);
      console.log("typePlan --> " + typePlan);


  /*
      if(installmentOptions !== "No_options"){
        const jsonData = JSON.parse(installmentOptions);
        const quoteId = jsonData.options.find((option: { number: any; }) => option.number === request.installments)?.quote_id; 

        console.log("quoteId -- " + quoteId);
      } else {
        console.log("No hubo opciones -- ");
      }
  */
      console.log(" ");
      console.log("----------------------------------------------------------------");
      console.log("-------- Mandamos a pago paso 4  (Security Proxy)---------------");

      let body = {
        "transaction_channel_type": "digital",
        "capture_mode": "automatic",
        "order": {
          "order_id": request.paymentId
        },
        "currency": currency,
        "amount": request.value * 100,
  /*      "installment": {
          "quote_id": "6d2e4380-d8a3-4ccb-9138-c289182818a3",
          "type": typePlan,
          "number": request.installments,
          "schema": "Ahora Plan",
          "interest_rate": interest_rate
        },*/
        "payment_method": {
          "token_id": tokenID,
          "security_code": request.card.cscToken   //request.card.csc
        },
        "customer": {
          "customer_id": request.miniCart.buyer.id,
          "first_name": request.miniCart.buyer.firstName,
          "last_name": request.miniCart.buyer.lastName,
          "name": name,
          "email": request.miniCart.buyer.email,
          "document_type": "dni",
          "document_number": request.miniCart.buyer.document,
          "phone_number": request.miniCart.buyer.phone,
          "billing_address": {
            "street": request.miniCart.billingAddress?.street.substring(0, 59),
            "number": request.miniCart.billingAddress?.number,
            "complement": request.miniCart.billingAddress?.complement,
            "city": request.miniCart.billingAddress?.city.substring(0, 39),
            "state": request.miniCart.billingAddress?.state.substring(0, 19),
            "country": countryBilling,
            "postal_code": request.miniCart.billingAddress?.postalCode
          },
          "gender": "Male",
          "checked_email": false
        },
        "shipping": {
          "first_name": request.miniCart.buyer.firstName,
          "last_name": request.miniCart.buyer.lastName,
          "shipping_amount": request.miniCart.shippingAddress?.shippingValue,
          "address": {
            "street": request.miniCart.shippingAddress?.street.substring(0, 59),
            "number": request.miniCart.shippingAddress?.number,
            "complement": request.miniCart.shippingAddress?.complement,
            "city": request.miniCart.shippingAddress?.city.substring(0, 39),
            "state": request.miniCart.shippingAddress?.state.substring(0, 19),
            "country": countryShipping,
            "postal_code": request.miniCart.shippingAddress?.postalCode
          }
        },
        "device_fingerprint": request.deviceFingerprint=null?request.deviceFingerprint:"null"
      };

      const bodyJSON = JSON.stringify(body);    
      console.log(bodyJSON);


      const response = await axios.post(request.secureProxyUrl, body, {
        headers: {
          'X-Vtex-Use-Https': 'true',
          'Proxy-Authorization': data.authToken,
          'X-PROVIDER-Forward-Content-Type': 'application/json',
          'X-PROVIDER-Forward-Authorization': 'Bearer ' + token,
          'X-PROVIDER-Forward-To' : 'https://api.pre.globalgetnet.com/checkout/v1/payments'
        },
      });

      const resp = response.data;      
/*
      const respp: respDummy = {
        paymentId: request.paymentId,
        status: "denied",
        tid: request.paymentId,
        code: null,
        message: "Payment Denied"
    };
*/

      return resp;

    } catch (error) {
      console.log(`Error al enviar la solicitud POST: ${error}`);
      return '{"status":"error","message":"'+error+'"}'
    }
  }

}





  /**
   * 
   * @param request 
   * @returns 
   */
  export async function getToken(request: any): Promise<any> {
    try {
      console.log(" ");
      console.log("----------------------------------------------------------------");
      console.log("-------- Generando token paso 1 ---------------")

      const url = 'http://api.pre.globalgetnet.com/authentication/oauth2/access_token';
      const data = new URLSearchParams();
      data.append('grant_type', 'client_credentials');
      data.append('client_id', request.apiKey);
      data.append('client_secret', request.appToken);

      const response = await axios.post(url, data.toString(), {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-Vtex-Use-Https': 'true',
          'Proxy-Authorization': request.authToken
        },
      });

        const resulObject = response.data;

        const paymentResponse = JSON.stringify(resulObject);
      console.log("respuesta WS token - " + paymentResponse);
      return resulObject.access_token;

    } catch (error) {
      console.log(`Error en la solicitud POST: ${error}`);
      return "error";
    }
}





  /**
   * 
   * @param token 
   * @param data 
   * @param paymentID 
   * @returns 
   */
  export async function Cancel(token: any, data: any, request: any): Promise<any> {
    try {
      //buscaremos el paymentID que para getnet es OrderID
      let paymentIDGetnet =  await getPaymentID(request, data.authToken, token);

      //el resultado nos regresara el paymentID que pasaremos a la cancelacion
      const response = await axios.post('https://api.pre.globalgetnet.com/checkout/v1/payments/'+paymentIDGetnet+'/cancellation', '', {
        headers: {
          'Content-Type': 'application/json',
          'X-Vtex-Use-Https': 'true',
          'Proxy-Authorization': data.authToken,
          'Authorization': 'Bearer ' + token
        },
      });


      console.log("-- -- -- -- -- -- --");
      const resp = response.data;
      const paymentResponse = JSON.stringify(resp);
      console.log("respuesta WS payment - " + paymentResponse);

      return resp;

    } catch (error) {
      console.log(`Error al enviar la solicitud POST al cancel: ${error}`);
      return "error";
    }
  }




  /**
   * 
   * @param token 
   * @param amount 
   * @param data 
   * @param paymentID 
   * @returns 
   */
  export async function Refund(token: any, data: any, request: any): Promise<any> {
    try {
      //buscaremos el paymentID que para getnet es OrderID
      let paymentIDGetnet =  await getPaymentID(request, data.authToken, token);
      //el resultado nos regresara el paymentID que pasaremos al refund

      let body = {
        "amount": request.value * 100
      };

      const bodyJSON = JSON.stringify(body);    
      console.log(bodyJSON);

      const response = await axios.post('https://api.pre.globalgetnet.com/checkout/v1/payments/'+paymentIDGetnet+'/refund', body, {
        headers: {
          'Content-Type': 'application/json',
          'X-Vtex-Use-Https': 'true',
          'Proxy-Authorization': data.authToken,
          'Authorization': 'Bearer ' + token
        },
      });
      
      

      console.log("-- -- -- -- Refund -- -- -- --");
      const resp = response.data;
      const paymentResponse = JSON.stringify(resp);
      console.log("respuesta WS payment - " + paymentResponse);

      return resp;

    } catch (error) {
      console.log(`Error al enviar la solicitud POST al refund: ${error}`);
      return "error";
    }
  }



  /**
   * 
   * @param request 
   * @param typePlan 
   * @param tokenProxy 
   * @param token 
   * @returns 
   */
  export async function installmentQuote(request: any, typePlan:any, tokenProxy: any, token: any, plan: any): Promise<any> {
    try {

      console.log(" ");
      console.log("----------------------------------------------------------------");
      console.log("-------- Busqueda de Meses (installments) paso 3 ---------------")

      const bin = request.card.bin + '00';      

      let body = {
          "installment_schema": [
            plan
          ],
          "installment_type": [
            typePlan
          ],
          "number_installments": [
            request.installments
          ],
          "amount": request.value * 100,
          "bin": parseInt(bin)
        };

//      const bodyJSON = JSON.stringify(body);    
//      console.log(bodyJSON);

      const response = await axios.post('https://api.pre.globalgetnet.com/checkout/v1/installment-quotes', body, {
        headers: {
          'Content-Type': 'application/json',
          'X-Vtex-Use-Https': 'true',
          'Proxy-Authorization': tokenProxy,
          'Authorization': 'Bearer ' + token
        },
      });    

      const resp = response.data;
      const paymentResponse = JSON.stringify(resp);
      console.log("respuesta WS installments - " + paymentResponse);

      return resp;

    } catch (error) {
      console.log(`Sin exito al enviar el POST a installments: ${error}`);
      return "No_options";
    }
  }




  /**
   * 
   * @param request 
   * @param tokenProxy 
   * @param token 
   * @returns 
   */
  export async function getPaymentID(request: any, tokenProxy: any, token: any): Promise<any> {
    try {

      console.log("-------- Consulta de la orden ---------------")

      const response = await axios.get('https://api.pre.globalgetnet.com/checkout/v1/payments?sort=updated_at&order_id='+request.paymentId+'&customer_id='+request.miniCart.buyer.id, {
        headers: {
          'Content-Type': 'application/json',
          'X-Vtex-Use-Https': 'true',
          'Proxy-Authorization': tokenProxy,
          'Authorization': 'Bearer ' + token
        },
      });    

      console.log("-- -- -- getPaymentID-- -- -- --");
      const resp = response.data;

      const paymentId = resp.docs[0].payment_id;
      console.log("paymentId consultado = " + paymentId);

      return paymentId;

    } catch (error) {
      console.log(`Sin exito al enviar el GET a getPaymentID: ${error}`);
      return "No_options";
    }
  }




  /**
   * 
   * @param numeroDeTarjeta 
   * @returns 
   */
    function getBrandCard(numeroDeTarjeta: string): string {
        // Expresiones regulares para cada tipo de tarjeta
      const regexAMEX = /^3[47][0-9]{4}$/;
      const regexMASTER = /^5[1-5][0-9]{4}$/;
      const regexVISA = /^4[0-9]{6}$/;
      const regexMAESTRO = /^(?:5[0678]\d\d|6304|6390|67\d\d)\d{8,15}$/;
      const regexNARANJA = /^(589562)\d{10}$/;
      const regexCABAL = /^(589657|603522|604202| 604400|650272|604201|650087)\d{10}$/;

      if (regexAMEX.test(numeroDeTarjeta)) {
        return "AMEX";
      } else if (regexMASTER.test(numeroDeTarjeta)) {
        return "MASTER";
      } else if (regexVISA.test(numeroDeTarjeta)) {
        return "VISA";
      } else if (regexMAESTRO.test(numeroDeTarjeta)) {
        return "MAESTRO";
      } else if (regexNARANJA.test(numeroDeTarjeta)) {
        return "NARANJA";
      } else if (regexCABAL.test(numeroDeTarjeta)) {
        return "CABAL";
      } else {
        return "VISA";
      }
  }

  


  /**
   * 
   * @param country 
   * @returns 
   */
  function getCountryCode(country: string): string {

      let codigo;

      if(country == 'ARG'){
          codigo = 'AR';
        }else if("ALE"){
          codigo = 'DE';
        }else if("BRL"){
          codigo = 'BR';
        }else if("CHL"){
          codigo = 'CL';
        }else if("COL"){
          codigo = 'CL';
        }else if("ESP"){
          codigo = 'ES';
        }else if("MEX"){
          codigo = 'MX';
        }else if("URU"){
          codigo = 'UY';
        }else if("USA"){
          codigo = 'US';

        } else {
          codigo = 'AR'; //default
        }

    return codigo
  }