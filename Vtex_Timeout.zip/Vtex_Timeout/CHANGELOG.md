# Changelog
Primera versión

### Added
- Se habilita el pago, cancelación y reembolso como operaciones validas

### Changed
- Updated README style
- Fixed connector testing instructions
- Improved readability

## [1.3.0] - 2021-12-21

## [1.2.0] - 2021-12-21
