import {
  AuthorizationRequest,
  CardAuthorization,
  AuthorizationResponse,
  CancellationRequest,
  CancellationResponse,
  Cancellations,
  PaymentProvider,
  RefundRequest,
  RefundResponse,
  Refunds,
  SettlementRequest,
  SettlementResponse,
  Settlements,
  InboundRequest,
 } from '@vtex/payment-provider'

import { VBase } from '@vtex/api'

import { randomString } from './utils'
import { getnetPayment, testAuthorization , getnetCancel, getnetRefund, generateAuth} from './flow'

const authorizationsBucket = 'authorizations'

const getPersistedAuthorizationResponse = async (
  vbase: VBase,
  req: AuthorizationRequest
) =>
  vbase.getJSON<AuthorizationResponse | undefined>(
    authorizationsBucket,
    req.paymentId,
    true
  )

export default class Getnet extends PaymentProvider {

  
  public async authorize(
    authorization: CardAuthorization,
  ): Promise<any> {


    if (this.isTestSuite) {
      return testAuthorization(authorization)

    } else {
      const persistedResponse = await getPersistedAuthorizationResponse(
        this.context.clients.vbase,
        authorization
      )

      if (persistedResponse !== undefined && persistedResponse !== null) {
        return persistedResponse
      } 

      const dataHeader = { apiKey: this.apiKey, appToken: this.appToken, authToken: this.context.vtex.authToken };
      return getnetPayment(authorization, dataHeader)
    }
  }

  
  /**
   * 
   * @param cancellation 
   * @returns 
   */
  public async cancel(cancellation: CancellationRequest): Promise<CancellationResponse> {
    if (this.isTestSuite) {
      return Cancellations.approve(cancellation, {
        cancellationId: randomString(),
      })
    
    } else {
      const dataHeader = { apiKey: this.apiKey, appToken: this.appToken, authToken: this.context.vtex.authToken };
      return getnetCancel(cancellation, dataHeader)
    }
    
  }



  /**
   * 
   * @param refund 
   * @returns 
   */
  public async refund(refund: RefundRequest): Promise<RefundResponse> {
    if (this.isTestSuite) {
      return Refunds.deny(refund)
    
    } else {
      const dataHeader = { apiKey: this.apiKey, appToken: this.appToken, authToken: this.context.vtex.authToken };
      return getnetRefund(refund, dataHeader)
    }

  }



  /**
   * 
   * @param settlement 
   * @returns 
   */
  public async settle(
    settlement: SettlementRequest
  ): Promise<SettlementResponse> {

    let codeAuth = generateAuth();

      return Settlements.approve(settlement, {
        settleId: codeAuth,
      })
  }

  /**
   * 
   * @param inbound 
   * @returns 
   */
  public async inbound(
    inbound: InboundRequest
  ): Promise<any> {

      const datos = [
        { 
          requestId: inbound.requestId,
          paymentId: inbound.paymentId,
          responseData: {
            statusCode: 200,
            contentType: "application/json"
          } 
        }
    ];

    return datos;
  }

}