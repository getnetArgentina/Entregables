import { PaymentProviderService } from '@vtex/payment-provider'

import Getnet from './connector'

export default new PaymentProviderService({
  connector: Getnet,
})
