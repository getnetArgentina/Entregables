import {
  Authorizations,
  Cancellations,
  Refunds,
  CardAuthorization,
  CancellationRequest,
  RefundRequest,
} from '@vtex/payment-provider'

import { paymentWS, getToken, Tokenize, Cancel, Refund} from './clientGetnetWS'

import { randomString } from './utils'


export const testAuthorization = async (
  request: CardAuthorization
): Promise<any> => {
    return Authorizations.approve(request, {
      authorizationId: randomString(),
      nsu: randomString(),
      message:' ',
      tid: randomString(),
    })
}



export const getnetPayment = async (
  request: CardAuthorization,  dataHeader: any
): Promise<any> => {

    console.log("-- -- -- Payment -- -- --");
    
    try {
      let tokenRes =  await getToken(dataHeader);

      let tokenCardID =  await Tokenize(tokenRes, request.card, dataHeader);

      let resultado =  await paymentWS(tokenCardID, request, dataHeader, tokenRes);
      console.log("payment_id --> " + resultado.payment_id);
      console.log("status --> " + resultado.status);

      if(resultado.status == "Authorized"){
        return Authorizations.approve(request, {
                authorizationId: resultado.authorization_code,
                acquirer: 'Getnet',
                nsu: resultado.payment_id,
                tid: resultado.payment_id,
              })
      } else {
          return Authorizations.deny(request, { tid: randomString(), message: "Payment Denied" })
      }
    
  } catch (error) {
      console.log(error);
      return Authorizations.deny(request, { tid: randomString(), message: "Payment Denied" })
  }

}




export const getnetCancel = async (
  cancellation: CancellationRequest,  dataHeader: any
): Promise<any> => {

  console.log("-- -- -- Cancel -- -- --");

  let tokenRes =  await getToken(dataHeader);
  console.log("tokenRes --> " + tokenRes);

  let result =  await Cancel(tokenRes, dataHeader, cancellation);

  if(result.status == "Cancelled"){
    return Cancellations.approve(cancellation, {
            cancellationId: cancellation.paymentId,
            code: result.authorization_code,
          })
  } else {
      return Cancellations.deny(cancellation, { message: "Not Cancelled" })
  }

}



export const getnetRefund = async (
  refund: RefundRequest,  dataHeader: any
): Promise<any> => {

  console.log("-- -- -- Refund -- -- --");

  let tokenRes =  await getToken(dataHeader);
  console.log("tokenRes --> " + tokenRes);

  let result =  await Refund(tokenRes, dataHeader, refund);

  if(result.status == "Refunded"){
    return Refunds.approve(refund, {
        refundId: refund.paymentId,
            code: result.authorization_code,
          })
  } else {
      return Refunds.deny(refund, { message: "Not Refunded" })
  }

}



export function generateAuth(): string {
  // en primera fase se simulara este dato, despues se habilitara la autorizacion en 2 pasos
  const randomNumber = Math.floor(Math.random() * (99999999 - 10000000 + 1)) + 10000000 + "";
  return randomNumber;
}