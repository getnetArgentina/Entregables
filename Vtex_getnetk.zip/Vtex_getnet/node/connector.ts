import {
  AuthorizationRequest,
  CardAuthorization,
  AuthorizationResponse,
  CancellationRequest,
  CancellationResponse,
  PaymentProvider,
  RefundRequest,
  RefundResponse,
  SettlementRequest,
  SettlementResponse,
  Settlements,
  InboundRequest,
 } from '@vtex/payment-provider'

import { VBase } from '@vtex/api'

import { getnetPayment , getnetCancel, getnetRefund, generateRandomUUID} from './flow'

const authorizationsBucket = 'authorizations'

const getPersistedAuthorizationResponse = async (
  vbase: VBase,
  req: AuthorizationRequest
) =>
  vbase.getJSON<AuthorizationResponse | undefined>(
    authorizationsBucket,
    req.paymentId,
    true
  )

export default class Getnet extends PaymentProvider {

  
  public async authorize(
    authorization: CardAuthorization, 
  ): Promise<any> {

      const test = this.isTestSuite;

      const { vtex: { logger } } = this.context;
        logger.info('Init Getnet Payment')

        try{
          const persistedResponse = await getPersistedAuthorizationResponse(
            this.context.clients.vbase,
            authorization
          )
    
          if (persistedResponse !== undefined && persistedResponse !== null) {
            return persistedResponse
          }     

        } catch (error) {
          logger.info('error : ' + error)
        }

            const dataHeader = { apiKey: this.apiKey, appToken: this.appToken, authToken: this.context.vtex.authToken, test};
        return getnetPayment(authorization, dataHeader, this.context.vtex, this.context)
  }

  
  /**
   * 
   * @param cancellation 
   * @returns 
   */
  public async cancel(cancellation: CancellationRequest): Promise<CancellationResponse> {

      const test = this.isTestSuite;
 
      const dataHeader = { apiKey: this.apiKey, appToken: this.appToken, authToken: this.context.vtex.authToken, test };
      return getnetCancel(cancellation, dataHeader)
    
  }



  /**
   * 
   * @param refund 
   * @returns 
   */
  public async refund(refund: RefundRequest): Promise<RefundResponse> {

      const test = this.isTestSuite;

      console.log("-----Inicia Refund----");

      const dataHeader = { apiKey: this.apiKey, appToken: this.appToken, authToken: this.context.vtex.authToken, test};

      const refundResult = await getnetRefund(refund, dataHeader);

      return refundResult
  }



  /**
   * 
   * @param settlement 
   * @returns 
   */
  public async settle(
    settlement: SettlementRequest
  ): Promise<SettlementResponse> {

    let codeAuth = generateRandomUUID();

    console.log("-----Inicia settlement----");

      return Settlements.approve(settlement, {
        settleId: codeAuth,
        code: "200",
      })
  }


  /**
   * 
   * @param inbound 
   * @returns 
   */
  public async inbound(
    inbound: InboundRequest
  ): Promise<any> {

      const datos = [
        { 
          requestId: inbound.requestId,
          paymentId: inbound.paymentId,
          responseData: {
            statusCode: 200,
            contentType: "application/json"
          } 
        }
    ];

    return datos;
  }

}