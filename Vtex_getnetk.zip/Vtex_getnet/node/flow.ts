import {
  Authorizations,
  Cancellations,
  Refunds,
  CardAuthorization,
  CancellationRequest,
  RefundRequest,
} from '@vtex/payment-provider'

import { IOContext, Context, InstanceOptions, IOClients } from '@vtex/api';

import { clientGetnet } from './clientGetnetWS'

import { getToken, Cancel, Refund, getPaymentID} from './clientGetnetWS'

import { randomString } from './utils'


export const testAuthorization = async (
  request: CardAuthorization
): Promise<any> => {
    return Authorizations.approve(request, {
      authorizationId: randomString(),
      nsu: randomString(),
      message:' ',
      tid: randomString(),
    })
}



export const getnetPayment = async (
  request: CardAuthorization,  dataHeader: any, contextIO: IOContext, context: Context<IOClients>
): Promise<any> => {
  
  let resultado;
  let paso = "init";
  console.log("----------------------------------------------------------------");
    console.log("-- -- -- Init Payment provider-- -- --");

    const { vtex: { logger } } = context;
        logger.info('-getnetPayment-')

    const opciones: InstanceOptions = {
      headers: {
        'X-VTEX-Use-Https': 'true',
      },
      retries: 3,
    };

    try {
      let tokenRes =  await getToken(dataHeader);
              paso = paso == null ? 'BadToken' : 'GoodToken';
              logger.info(paso)

      const clienteGetnet = new clientGetnet(contextIO, opciones);

      if(tokenRes == null  || tokenRes.length < 10){
        paso = 'BadToken';

        return Authorizations.deny(request, { tid: generateRandomUUID(), message: "Session Token Error", "code":paso, acquirer:"Getnet", authorizationId:"null",  })

      } else { //obtuvimos token
        paso = 'GoodToken';

            //buscaremos el paymentID que para getnet es OrderID
            let paymentGetnet =  await getPaymentID(request, dataHeader.authToken, tokenRes);

            if (paymentGetnet.status == null){
              paso = 'buscaTX_error';

            } else if (paymentGetnet.status == 'Denied'){ //la busqueda no regreso resultado o fue denegado
              paso = 'getInfoTX_finded';
              let tokenCardID =  await clienteGetnet.Tokenize(tokenRes, request, dataHeader);   
              logger.info("tokenCardID - " + tokenCardID)

                  if(tokenCardID.length > 8){
                    paso = 'good_TokenCard';
                    resultado =  await clienteGetnet.paymentWS(tokenCardID, request, dataHeader, tokenRes);
                    paso = 'good_service_payment';

                    const paymentResponse = JSON.stringify(resultado);
                    console.log("respuesta WS payment - " + paymentResponse);

                  } else { 
                    paso = 'bad_TokenCard';
                  }
                    

            } else {
              paso = 'getInfoTX_finded';
              console.log("-------Payment encontrado y aprobado anteriormente ------");
              resultado = {
                      "authorization_code": paymentGetnet.authorization_code,
                      "payment_id": paymentGetnet.payment_id,
                      "status": paymentGetnet.status
                  };
            }

            if(resultado.status != null){
              if(resultado.status == "Authorized"){
                paso = "tx_approved";
                console.log("Pago aprobado --> status: " + resultado.status);
            
                return Authorizations.approve(request, {
                        authorizationId: resultado.authorization_code,
                        acquirer: 'Getnet',
                        nsu: resultado.payment_id,
                        tid: resultado.payment_id,
                        delayToAutoSettle: 600,
                        message: paso,
                    })
        
              } else {
                return Authorizations.deny(request, { tid: generateRandomUUID(), message: "Trx no aprobada", "code":paso, acquirer:"Getnet", authorizationId:"null",  })
              }
    
          } else {
            console.log("Pago Denegado");
            return Authorizations.deny(request, { tid: generateRandomUUID(), message: "Flujo no terminado", "code":paso, acquirer:"Getnet", authorizationId:"null",  })
          }
      }

    
  } catch (error) {
      console.log(error);
      logger.info("error - " + error)
      return Authorizations.deny(request, { tid: randomString(), message: "Flow Error: " + error , "code":paso})
  }

}




export const getnetCancel = async (
  cancellation: CancellationRequest,  dataHeader: any
): Promise<any> => {

  console.log("-- -- -- Cancel -- -- --");

  let tokenRes =  await getToken(dataHeader);

  let result =  await Cancel(tokenRes, dataHeader, cancellation);

  if(result.status == "Cancelled"){
    return Cancellations.approve(cancellation, {
            cancellationId: cancellation.paymentId,
            code: result.authorization_code,
          })
  } else {
      return Cancellations.deny(cancellation, { message: "Not Cancelled" })
  }

}



export const getnetRefund = async (
  refund: RefundRequest,  dataHeader: any
): Promise<any> => {

  console.log("-- -- -- Refund -- -- --");

  let tokenRes =  await getToken(dataHeader);

  let result =  await Refund(tokenRes, dataHeader, refund);
     console.log(result);

  if(result.status == "Refunded"){
    
    return { paymentId: refund.paymentId, 
             refundId: result.payment_id.replace("-", ""), 
             value: refund.value, 
             code: result.authorization_code,  
             message: "Successfully refunded", 
             requestId: refund.requestId,
          }

  } else {
      return Refunds.deny(refund, { message: "Not Refunded" })
  }

}



export function generateAuth(): string {
  // en primera fase se simulara este dato, despues se habilitara la autorizacion en 2 pasos
  const randomNumber = Math.floor(Math.random() * (99999999 - 10000000 + 1)) + 10000000 + "";
  return randomNumber;
}



export function generateRandomString(length: number): string {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

export function generateRandomUUID(): string {
  const sections = [8, 4, 4, 4, 12]; // Longitud de cada sección del UUID
  return sections.map(section => generateRandomString(section)).join('-');
}
