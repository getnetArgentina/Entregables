import { PaymentProviderService } from '@vtex/payment-provider'

import { ServiceContext, RecorderState, ParamsContext } from '@vtex/api'

import { method, IOClients } from '@vtex/api'

import Getnet from './connector'


type CustomContext = ServiceContext<IOClients, RecorderState, ParamsContext>


// Middleware para manejar el método POST en /payments/status
async function statusHandler(ctx: CustomContext) {
  ctx.response.status = 200
  ctx.response.body = 'OK'
}

export default new PaymentProviderService({
  connector: Getnet,
  routes: {
    status: method({
      POST: [statusHandler],
    }),
  },
})
