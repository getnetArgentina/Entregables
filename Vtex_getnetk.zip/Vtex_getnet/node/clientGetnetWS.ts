import axios from 'axios';
import { SecureExternalClient } from '@vtex/payment-provider';
import { URLSearchParams } from "url"
import { IOContext, InstanceOptions } from '@vtex/api';


export class clientGetnet extends SecureExternalClient {
  constructor(protected context: IOContext, options?:InstanceOptions | undefined){
  super('https://api.globalgetnet.com', context, options);
  }


  /**
   * 
   * @param token 
   * @param request 
   * @param data 
   * @returns 
   */
  async Tokenize(token: any, request: any, data: any): Promise<any> {
   
    console.log(" ");
    console.log("----------------------------------------------------------------");
    console.log("-------- Tokenizamos paso 2---------------")

    try {

      let Year = request.card.expiration.year.length == 4 ?  request.card.expiration.year.substring(2, 4) : request.card.expiration.year;

      const card = request.card.numberToken == null ? request.card.number : request.card.numberToken;
      const cardHolder = request.card.holderToken == null ?  request.card.holder : request.card.holderToken;

      const bin = card.includes("#") ? request.card.bin  : card.substring(0, 6) ;
      const brand = getBrandCard(bin);

      const urlEndpoint = card.includes("#") ? request.secureProxyUrl : "https://api.globalgetnet.com/checkout/v1/tokens";

      console.log("Brand " + brand);

      let body = {
        "method_type": "card",
        "card_pan": card,
        "brand": brand,
        "cardholder_name": cardHolder,
        "expiration_month": request.card.expiration.month,
        "expiration_year": Year
      };
      
//      console.log("tokeniza --> " + JSON.stringify(body));

      const response = await axios.post(urlEndpoint, body, {
        headers: {
          'X-Vtex-Use-Https': 'true',
          'Proxy-Authorization': data.authToken,
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token,
          'X-PROVIDER-Forward-Content-Type': 'application/json',
          'X-PROVIDER-Forward-Authorization': 'Bearer ' + token,
          'X-PROVIDER-Forward-To' : 'https://api.globalgetnet.com/checkout/v1/tokens'
        },
      });

      const resp = response.data

      const paymentResponse = JSON.stringify(resp);
      console.log("respuesta WS tokenize - " + paymentResponse);

      return resp.token_id;

    } catch (error) {
      console.log(`Error al enviar la solicitud POST: ${error}`);
      return "error";
    }
  }




  /**
   * 
   * @param tokenID 
   * @param request 
   * @param data 
   * @param token 
   * @returns 
   */
  async paymentWS(tokenID: any, request: any, data: any, token: any): Promise<any> {

    try {
      //buscamos si fue pagada anteriormente

      let installmentOptions: any;

      //le quitamos el punto, es equivalente a multiplicar por 100
      const amount: number = Amountformat(request.value + "");
      const currency = request.currency;

      const countryShipping = getCountryCode(request.miniCart.shippingAddress?.country);
      const countryBilling = getCountryCode(request.miniCart.billingAddress?.country);
      const name = request.miniCart.buyer.firstName + " " + request.miniCart.buyer.lastName;
      const DNI = request.miniCart.buyer.document.length < 8 ? "99999999" : request.miniCart.buyer.document;
      const numberPhone = request.miniCart.buyer.phone.length < 8 || request.miniCart.buyer.phone.length > 15 ? "5491199999" : request.miniCart.buyer.phone;
      const csc = request.card.cscToken == null ? request.card.csc : request.card.cscToken;
      const urlEndpoint = csc.includes("#") ? request.secureProxyUrl : "https://api.globalgetnet.com/checkout/v1/payments";
      
      console.log("complement Shipping -" + request.miniCart.shippingAddress?.complement);
      console.log("----------------------------------------------------------------");
      console.log("-------- Armamos body payment paso 3  (Security Proxy)---------------");

      let body: any = {
        "transaction_channel_type": "digital",
        "capture_mode": "automatic",
        "order": {
          "order_id": request.paymentId
        },
        "currency": currency,
        "amount": amount,
        "payment_method": {
          "token_id": tokenID,
          "security_code": csc
        },
        "customer": {
          "customer_id": request.miniCart.buyer.id,
          "first_name": request.miniCart.buyer.firstName,
          "last_name": request.miniCart.buyer.lastName,
          "name": name,
          "email": request.miniCart.buyer.email,
          "document_type": "dni",
          "document_number": DNI,
          "phone_number": numberPhone,
          "billing_address": {
            "street": request.miniCart.billingAddress?.street.substring(0, 59),
            "number": request.miniCart.billingAddress?.number,
            "city": request.miniCart.billingAddress?.city.substring(0, 39),
            "state": request.miniCart.billingAddress?.state.substring(0, 19),
            "country": countryBilling,
            "postal_code": request.miniCart.billingAddress?.postalCode
          },
          "gender": "Male",
          "checked_email": false
        },
        "shipping": {
          "first_name": request.miniCart.buyer.firstName,
          "last_name": request.miniCart.buyer.lastName,
          "address": {
            "street": request.miniCart.shippingAddress?.street.substring(0, 59),
            "number": request.miniCart.shippingAddress?.number,
            "city": request.miniCart.shippingAddress?.city.substring(0, 39),
            "state": request.miniCart.shippingAddress?.state.substring(0, 19),
            "country": countryShipping,
            "postal_code": request.miniCart.shippingAddress?.postalCode
          }
        },
        "device_fingerprint": request.deviceFingerprint=null?request.deviceFingerprint:"null"
      };


      if(request.installments > 1){ // Se eligio plan a meses
        console.log("pago a meses");
        installmentOptions =  await installmentQuote(request, data.authToken, token);

        if(installmentOptions == 'No_options'){
            return '{"status":"denied","message":"No_options"}'

        } else {
              try{
                // Parsear las cadenas JSON en objetos TypeScript
                let objeto1: { [key: string]: any } = body;

                let objeto2: { [key: string]: any } = installmentOptions;

                // Agregar las propiedades del segundo objeto al primero
                for (let key in objeto2) {
                    if (objeto2.hasOwnProperty(key)) {
                        objeto1[key] = objeto2[key];
                    }
                }

                // Convertir el objeto resultante a una cadena JSON
                body= JSON.stringify(objeto1);

              } catch (error) {
                console.log("error ===== " + error);
            }

        }
       
      } 
      
//      console.log(body);
      

      const response = await axios.post(urlEndpoint, body, {
        headers: {
          'X-Vtex-Use-Https': 'true',
          'Proxy-Authorization': data.authToken,
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token,
          'X-PROVIDER-Forward-Content-Type': 'application/json',
          'X-PROVIDER-Forward-Authorization': 'Bearer ' + token,
          'X-PROVIDER-Forward-To' : 'https://api.globalgetnet.com/checkout/v1/payments'
        },
      });

      const resp = response.data;
      const paymentResponse = JSON.stringify(resp);
      console.log("respuesta WS payment - " + paymentResponse);

      return resp;

    } catch (error) {
      console.log(`Error al enviar la solicitud POST: ${error}`);
      return '{"status":"error","message":"'+error+'"}'
    }
  }

}


  /**
   * 
   * @param request 
   * @returns 
   */
  export async function getToken(request: any): Promise<any> {
    try {
      console.log(" ");
      console.log("----------------------------------------------------------------");
      console.log("-------- Generando token paso 1 ---------------")

      const url = 'http://api.globalgetnet.com/authentication/oauth2/access_token';
      const data = new URLSearchParams();
      data.append('grant_type', 'client_credentials');
      data.append('client_id', request.apiKey);
      data.append('client_secret', request.appToken);

      console.log("url: " + url);

      const response = await axios.post(url, data.toString(), {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-Vtex-Use-Https': 'true',
          'Proxy-Authorization': request.authToken
        },
      });

        const resulObject = response.data;
//        const paymentResponse = JSON.stringify(resulObject);
//          console.log("respuesta WS token - " + paymentResponse);

      return resulObject.access_token;

    } catch (error) {
      console.log(`Error en la solicitud getToken: ${error}`);
      return "error";
    }
}





  /**
   * 
   * @param token 
   * @param data 
   * @param paymentID 
   * @returns 
   */
  export async function Cancel(token: any, data: any, request: any): Promise<any> {
    try {
      //buscaremos el paymentID que para getnet es OrderID
      let paymentIDInfo =  await getPaymentID(request, data.authToken, token);
      console.log("trx status = " + paymentIDInfo.status);

      if (paymentIDInfo.status == 'Denied'){ //no se encontro el ID en Getnet
        return "error";
      
      } else { //el resultado nos regresara el paymentID que pasaremos a la cancelacion
          const response = await axios.post('https://api.globalgetnet.com/checkout/v1/payments/'+paymentIDInfo.payment_id+'/cancellation', '', {
            headers: {
              'Content-Type': 'application/json',
              'X-Vtex-Use-Https': 'true',
              'Proxy-Authorization': data.authToken,
              'Authorization': 'Bearer ' + token
            },
          });

          const resp = response.data;
//          const paymentResponse = JSON.stringify(resp);
//          console.log("respuesta WS payment Cancel- " + paymentResponse);

      return resp;
      }


    } catch (error) {
      console.log(`Error al enviar la solicitud POST al cancel: ${error}`);
      return "error";
    }
  }




  /**
   * 
   * @param token 
   * @param amount 
   * @param data 
   * @param paymentID 
   * @returns 
   */
  export async function Refund(token: any, data: any, request: any): Promise<any> {
    try {

          //buscaremos el paymentID que para getnet es OrderID
          let paymentIDInfo =  await getPaymentID(request, data.authToken, token);
          
          const amount: number = Amountformat(request.value + "");

          if (paymentIDInfo.status == 'Denied'){ //no se encontro el ID en Getnet
            return "error";
          
          } else { // se encontro y procedemos al refund
              let body = {
                "amount": amount
              };

              const response = await axios.post('https://api.globalgetnet.com/checkout/v1/payments/'+paymentIDInfo.payment_id+'/refund', body, {
                headers: {
                  'Content-Type': 'application/json',
                  'X-Vtex-Use-Https': 'true',
                  'Proxy-Authorization': data.authToken,
                  'Authorization': 'Bearer ' + token
                },
              });              

              console.log("-- -- -- -- Refund -- -- -- --");
              console.log("https://api.globalgetnet.com/checkout/v1/payments/"+paymentIDInfo.payment_id+"/refund");
              const resp = response.data;
//              const paymentResponse = JSON.stringify(resp);
//              console.log("respuesta WS payment Refund- " + paymentResponse);

          return resp;
        }

    } catch (error) {
      console.log(`Error al enviar la solicitud POST al refund: ${error}`);
      return "error";
    }
  }



  /**
   * 
   * @param request 
   * @param typePlan 
   * @param tokenProxy 
   * @param token 
   * @returns 
   */
  export async function installmentQuote(request: any,  tokenProxy: any, token: any): Promise<any> {

    try {
      const merchantSettingsArray = request.merchantSettings;
      let installment: any;
      let plan;


      if (merchantSettingsArray) {
          merchantSettingsArray.forEach((setting: { name: any; value: any; }) => {
            const name = setting.name;
            const value = setting.value;

            if(name == 'Planes'){
              plan = value;
            }

          });
      } 

      const amount: number = Amountformat(request.value + "");

      let planes= plan == 'planA' ? 'plan_ahora' : 'plan_emisor';
      let typePlan = "no_interest";
//      let typePlan = request.installmentsInterestRate > 0 ? "with_interest": "no_interest";

      const brand = getBrandCard(request.card.bin);

      if(brand == 'VISA' && plan == 'planE'){
        planes = 'plan_emisor_accelerated';
     
      } else if(brand == 'AMEX' && plan == 'planE'){ //Plan Emisor
        planes = 'plan_n';

      } else if(brand == 'AMEX' && plan == 'planA'){  //cuota simple
        planes = 'plan_ahora';

      } else if(brand == 'NARANJA'){
        planes = 'pago_en_cuota';

      } else if(brand == 'CABAL'){
        planes = 'plan_emisor';

      }

      console.log(planes);

      console.log("----------------------------------------------------------------");
      console.log("-------- Busqueda de Meses (installments) paso 4 ---------------")

      const bin = request.card.bin + '00';      

      let body = {
          "installment_schema": [
            planes
          ],
          "installment_type": [
            typePlan
          ],
          "number_installments": [
            request.installments
          ],
          "amount": amount,
          "bin": parseInt(bin)
        };

//      const bodyJSON = JSON.stringify(body);    
//      console.log(bodyJSON);

      const response = await axios.post('https://api.globalgetnet.com/checkout/v1/installment-quotes', body, {
        headers: {
          'Content-Type': 'application/json',
          'X-Vtex-Use-Https': 'true',
          'Proxy-Authorization': tokenProxy,
          'Authorization': 'Bearer ' + token
        },
      });    

      const resp = response.data;
//      const paymentResponse = JSON.stringify(resp);
//      console.log("respuesta WS installments - " + paymentResponse);

      try{
          if(resp.options[0].quote_id !== null){
            installment = { 
                            "installment": {
                                    "quote_id": resp.options[0].quote_id,
                                    "type": resp.options[0].type,
                                    "number": resp.options[0].number, 
                                    "schema": resp.options[0].schema
                            }
            };
//            console.log(installment);
          }
       } catch (error) {
        console.log("No_options");
        return "No_options";
      }


      return installment;

    } catch (error) {
      console.log(`Sin exito al enviar el POST a installments: ${error}`);
      return "No_options";
    }
  }




  /**
   * 
   * @param request 
   * @param tokenProxy 
   * @param token 
   * @returns 
   */
  export async function getPaymentID(request: any, tokenProxy: any, token: any): Promise<any> {
    
    let paymentIDinfo;

    try {
        console.log("-------- Consulta de la orden ---------------> " + request.paymentId)

        const response = await axios.get('https://api.globalgetnet.com/checkout/v1/payments?sort=updated_at&order_id='+request.paymentId, {
//        const response = await axios.get('https://api.globalgetnet.com/checkout/v1/payments?sort=updated_at&order_id='+request.paymentId+'&customer_id='+request.miniCart.buyer.id, {
          headers: {
            'Content-Type': 'application/json',
            'X-Vtex-Use-Https': 'true',
            'Proxy-Authorization': tokenProxy,
            'Authorization': 'Bearer ' + token
          },
        });    

        console.log("-- -- -- getPaymentID-- -- -- --");
        const resp = response.data;
//        console.log("respuesta consulta WS getPaymentID - " + JSON.stringify(resp));

           if(resp.total > 0){
               paymentIDinfo = {
                authorization_code: resp.docs[0].authorization_code,
                payment_id: resp.docs[0].payment_id,
                status: resp.docs[0].status
              }; 

            } else {
              paymentIDinfo = {
                status: "Denied"
              }; 
            }            
        
      } catch (error) {
        console.log(`Sin exito al enviar el GET a getPaymentID: ${error}`);
        paymentIDinfo = {
          status: "Denied"
        }; 
      }

    return paymentIDinfo;

  }




  /**
   * 
   * @param numeroDeTarjeta 
   * @returns 
   */
    function getBrandCard(numeroDeTarjeta: string): string {
        // Expresiones regulares para cada tipo de tarjeta
      const regexAMEX = /^3[47][0-9]{4}$/;
      const regexMASTER = /^5[1-5][0-9]{4}$/;
      const regexVISA = /^4[0-9]{6}$/;
      const regexMAESTRO = /^(?:5[0678]\d\d|6304|6390|67\d\d)\d{8,15}$/;
      const regexNARANJA = /^(589562)\d{10}$/;
      const regexCABAL = /^(589657|603522|604202| 604400|650272|604201|650087)\d{10}$/;

      if (regexAMEX.test(numeroDeTarjeta)) {
        return "AMEX";
      } else if (regexMASTER.test(numeroDeTarjeta)) {
        return "MASTER";
      } else if (regexVISA.test(numeroDeTarjeta)) {
        return "VISA";
      } else if (regexMAESTRO.test(numeroDeTarjeta)) {
        return "MAESTRO";
      } else if (regexNARANJA.test(numeroDeTarjeta)) {
        return "NARANJA";
      } else if (regexCABAL.test(numeroDeTarjeta)) {
        return "CABAL";
      } else {
        return "VISA";
      }
  }

  


  /**
   * 
   * @param country
   * @returns 
   */
  function getCountryCode(country: string): string {

      let codigo;

      if(country == 'ARG'){
          codigo = 'AR';
        }else if("ALE"){
          codigo = 'DE';
        }else if("BRL"){
          codigo = 'BR';
        }else if("CHL"){
          codigo = 'CL';
        }else if("COL"){
          codigo = 'CL';
        }else if("ESP"){
          codigo = 'ES';
        }else if("MEX"){
          codigo = 'MX';
        }else if("URU"){
          codigo = 'UY';
        }else if("USA"){
          codigo = 'US';

        } else {
          codigo = 'AR'; //default
        }

    return codigo
  }




/**
 * 
 * @param amount 
 * @returns 
 */
function Amountformat(amount: string): number {

  let amountInteger: number = parseInt(amount);
  var numDec = contarDecimales(amount);

  if(numDec == 0){
      amountInteger = (amountInteger * 100);

  } else if (numDec == 1){
      amount = amount.replace(".","");
      amountInteger = parseInt(amount+"0");

  } else if (numDec == 2){
      amount = amount.replace(".","");
      amountInteger = parseInt(amount);
  }

  console.log("amount after format: " + amountInteger);

  return amountInteger;
}



/**
 * 
 * @param numero 
 * @returns 
 */
function contarDecimales(numero: string): number {

    const posicionPuntoDecimal = numero.indexOf('.');
    if (posicionPuntoDecimal === -1) {
        return 0; // No hay decimales
    } else {
        return numero.length - posicionPuntoDecimal - 1;
    }

}