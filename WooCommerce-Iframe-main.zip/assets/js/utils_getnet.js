document.addEventListener('DOMContentLoaded', function() {
    const storeDomain = siteData.siteUrl;
});