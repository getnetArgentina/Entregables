# WooCommerce Shop Plugin

## Requirements

WooCommerce v6.9.3

## Installation

Install the WooCommerce Shop Plugin zip file as other WooCommerce plugins. The common methods are:

- [Upload via WooCommerce Admin](https://wordpress.org/support/article/managing-plugins/#upload-via-wordpress-admin)
- [Manual Plugin Installation](https://wordpress.org/support/article/managing-plugins/#manual-plugin-installation-1)

## Configuration

Once the plugin has been installed and enabled. The next step is to configure it.

### Enable the plugin

Navigate to the [WooCommerce Settings page](https://woocommerce.com/document/configuring-woocommerce-settings/). Select the Payments tab, it will show "GetNet" as a payment method.

![WooCommerce Settings page - Payments tab](/docs/images/woocommerce-payments-tab.jpg)

Click on "GetNet" method and configure the settings.

### Configurations

| Attribute     | Description           |
| ------------- |-------------|
| Enable gateway| Enables the gateway. Set as true|
| Enable testing mode| Enables the gateway testing mode. Set as false|
|Client ID|Value provided by GetNet|
|Client Secret|Value provided by GetNet|
|Pais|Value provided by GetNet|
|Tipo|Lightbox, iframe o redirect|
|User Webhook|Value provided by GetNet|
|Password Webhook|Value provided by GetNet|
