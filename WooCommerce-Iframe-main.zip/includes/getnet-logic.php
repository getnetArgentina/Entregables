<?php

add_action('wp_ajax_revisar_pagoqrgetnet', 'revisar_pagoqrgetnet', 1);
add_action('wp_ajax_nopriv_revisar_pagoqrgetnet', 'revisar_pagoqrgetnet', 1);

function revisar_pagoqrgetnet()
{
	if ($_POST['dataid']) {
		$order_id = $_POST['dataid'];
		// Verificar si HPOS está habilitado
		if (get_option('woocommerce_hpos_enabled') === 'yes') {
		    // Obtener metadatos del pedido desde las tablas de HPOS
		    global $wpdb;
		    $qr_data = $wpdb->get_var(
		        $wpdb->prepare(
		            "SELECT meta_value FROM {$wpdb->prefix}wc_order_meta WHERE order_id = %d AND meta_key = 'qr_status'",
		            $order_id
		        )
		        );
		} else {
		    // Obtener metadatos del pedido desde las tablas tradicionales
		    $qr_data = get_post_meta($order_id, 'qr_status', true);
		}
		
		if ($qr_data == 'approved') {
			$order = wc_get_order($order_id);
			$urlok = $order->get_checkout_order_received_url();
			echo $urlok;
			die();
		}
	}
	die();
}

/***
 * 
 * 
 */
function getnet_Iframe_init_gateway_class()
{
	class WC_GetnetIframe_Gateway extends WC_Payment_Gateway
	{
		public function __construct(){
//			define('MPQR_DIR_PATH', plugin_dir_path(__FILE__));
//			define('MPQR_DIR_URL', plugin_dir_url(__FILE__));
			$this->id = 'getnet_iframe_gateway';
			$this->icon = apply_filters('woocommerce_getnet_Iframe_icon', 'https://mitcommerce.net/resources/images/LOGO_GETNET_ROJO.png');
			$this->has_fields = false;
			$this->method_title = 'Getnet LATAM';
			$this->method_description = 'Pasarela de pagos Get Checkout';
			$this->supports = array(
				'products',
				'refunds',
				'cancel'
			);
			$this->init_form_fields();
			$this->init_settings();
			$this->title = 'Tarjeta de crédito, débito o prepago.';
			$this->description = 'Paga seguro todo lo que necesitas con Getnet.';
			$this->billing_descriptor = $this->get_option('billing_descriptor');
			$notification_url_webhook = get_site_url();

			$this->enabled = $this->get_option('enabled');
			$this->client_id = $this->get_option('client_id');
			$this->client_secret_id = $this->get_option('client_secret_id');
			$this->webhook_user = $this->get_option('webhook_user');
			$this->webhook_pass = $this->get_option('webhook_pass');
			$this->entorno_api = $this->get_option('entorno_api');
			$timezone = "America/Buenos_Aires";
			date_default_timezone_set($timezone);
			$this->date_time = date('Y:m:d-H:i:s');

			if ($this->entorno_api == 'yes') {
				$this->client_id = $this->get_option('client_id');
				$this->client_secret_id = $this->get_option('client_secret_id');

				$this->url_pago = 'https://api.pre.globalgetnet.com';
			} else {
				$this->client_id = $this->get_option('client_id');
				$this->client_secret_id = $this->get_option('client_secret_id');
				$this->url_pago = 'https://api.globalgetnet.com';
			}
			

			// Actions
            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
            
            // Action for the process callbacks
            add_action( 'woocommerce_api_getnet-success',array($this,'process_success'));
            add_action( 'woocommerce_api_getnet-cancel',array($this,'process_cancel'));
            
            // Action for the redirect
            add_action( 'woocommerce_getnet_Iframe_redirect', array( $this, 'process_redirect'));

            add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));
            
            add_action("woocommerce_api_getnet", [$this, "webhook"]);

			add_action('template_redirect', array($this, 'rudr_order_received_custom_payment_redirect'));
		}

		
        public function process_success($order_id) {
            if (!wc_has_notice('¡Gracias por tu compra!<br> Estimado cliente, hemos recibido tu pedido exitosamente. En las próximas horas recibirás un correo electrónico con los detalles de tu compra.')) {
                wc_add_notice('¡Gracias por tu compra!<br> Estimado cliente, hemos recibido tu pedido exitosamente. En las próximas horas recibirás un correo electrónico con los detalles de tu compra.', 'notice');
            }
        
            wp_redirect(home_url());
          }
        
        public function process_cancel() {
            wc_add_notice('El intento de pago ha fallado, intente nuevamente o seleccione otro método de pago', 'error');
            wp_redirect(wc_get_cart_url());
        }

    	public function process_payment($order_id) {
			$order = new WC_Order($order_id);
			return ['result' => 'success', 'redirect' => $order->get_checkout_payment_url(true)];
		}

		public function init_form_fields() {

			$this->form_fields = array(
				'enabled' => array(
					'title' => 'Habilitar/Deshabilitar',
					'label' => 'Habilitar Getnet',
					'type' => 'checkbox',
					'description' => '',
					'default' => 'no'
				),
				'client_id' => array(
					'title' => 'Client ID',
					'description' => 'Es el Client ID proporcionado por Getnet a la hora de dar de alta el servicio.',
					'type' => 'text',
					'desc_tip' => true,
				),
				'client_secret_id' => array(
					'title' => 'Client Secret',
					'description' => 'Es el Client Secret proporcionado por Getnet a la hora de dar de alta el servicio.',
					'type' => 'text',
					'desc_tip' => true,
				),
				'button_validate_keys' => array(
					'title' => 'Validar credenciales',
					'type' => 'button',
					'custom_attributes' => array(),
					'description' => '',
					'desc_tip' => true,
				),
				'country' => array(
				    'title' => 'País',
					'description' => 'Selecciona el país en que aceptarás tus pagos.',
					'type' => 'select',
					'desc_tip' => true,
					//'default' => 'CL',
					'options' => array(
                        'AR' => 'Argentina',
                        'CL' => 'Chile'
                    )
				),
				'product_type' => array(
				    'title' => 'Producto',
					'description' => 'Selecciona la forma en que se presentará la forma de pago.',
					'type' => 'select',
					'desc_tip' => true,
					//'default' => 'lightbox', 
					'options' => array(
                        'lightbox' => 'Lightbox',
                        'iframe' => 'Iframe',
                        'redirect' => 'Redirect'
                    )
				),
				'entorno_api' => array(
					'title' => 'Activar modo testeo',
					'label' => 'Activar',
					'type' => 'checkbox',
					'description' => 'Sirve para Activar / Desactivar el modo testeo. Es para hacer pruebas con el API de pruebas de Getnet.',
					'default' => 'no',
					'desc_tip' => true,
				),
				'section_divider' => array(
                    'type' => 'title',
                    'title' => '<hr> Información para configurar el Webhook en Getnet <hr>',
                ),
				'webhook_user' => array(
					'title' => 'Usuario WebHook',
					'description' => 'Ingresar usuario para WebHook',
					'type' => 'text',
					'desc_tip' => true,
				),
				'webhook_pass' => array(
					'title' => 'Password WebHook',
					'description' => 'Ingresar password para WebHook',
					'type' => 'text',
					'desc_tip' => true,
				),
				'webhook_url' => array(
					'title' => "Callback URL",
					'description' => 'URL para recibir notificaciones sobre el estado final de tus transacciones',
					'type' => 'text',
					'desc_tip' => true,
					'default' => get_site_url() . '/?wc-api=getnet',
					'custom_attributes' => array(
                        'readonly' => 'readonly'
                    ),
				),
				'redirect_url_success' => array(
					'title' => "URL en casos de éxito",
					'description' => 'URL para redirigir al usuario en caso de éxito, se configura en el portal de información Getnet',
					'type' => 'text',
					'desc_tip' => true,
					'default' => get_site_url() . '/wc-api/getnet-success',
					'custom_attributes' => array(
                        'readonly' => 'readonly'
                    ),
				),
				'redirect_url_cancel' => array(
					'title' => "URL en caso de error",
					'description' => 'URL para redirigir al usuario en caso de error, se configura en el portal de información Getnet',
					'type' => 'text',
					'desc_tip' => true,
					'default' => get_site_url() . '/wc-api/getnet-cancel',
					'custom_attributes' => array(
                        'readonly' => 'readonly'
                    ),
				)
			);
		}

		public function payment_fields() {
			if ($this->description) {
				echo wpautop(wp_kses_post($this->description));
			}
		}
		
		public function receipt_page($order) {
		    error_log('init receipt_page');
			echo $this->generate_qr_form($order);
		}
		
		public function process_refund($order_id, $amount = null, $reason = ''){
			global $woocommerce;
			$order = wc_get_order($order_id);
			$total = $order->get_total();
			$url = '';
			
			error_log('Transaction ID Refund --> ' . $order_id);
			

			$transaction_Resp = get_post_meta($order_id, 'Getnet_Response_Payment', true);
			$transaction_Resp = json_decode($transaction_Resp);
			
			error_log('Transaction ID Refund --> ' . $transaction_Resp->payment_id);

			$current_date = new WC_DateTime();

			$transaction_date = $transaction_Resp->transaction_datetime;
			$transaction_id = $transaction_Resp->payment_id;

			// Calcular la diferencia en horas
			$time_diff = strtotime($current_date) - strtotime($transaction_date);
			$hours_diff = $time_diff / 3600; // Convertir la diferencia a horas


			$url = $this->url_pago . '/digital-checkout/v1/payments/' . $transaction_id . '/refund';
			error_log('URL Refund --> ' . $url);
			
			$amount = str_replace('.', '', $amount);
			$amount = get_adjusted_amount_total($amount);

			$params = array(
				'transaction_id' => $transaction_id,
				'amount' => $amount,
			);


			error_log('Total conversión en REFUND --> ' . $amount);

			$curl = curl_init();

			curl_setopt_array(
				$curl,
				array(
					CURLOPT_URL => $this->url_pago . '/authentication/oauth2/access_token',
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => '',
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 0,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => 'POST',
					CURLOPT_POSTFIELDS => 'grant_type=client_credentials&client_secret=' . $this->client_secret_id . '&client_id=' . $this->client_id,
					CURLOPT_HTTPHEADER => array(
						'Content-Type: application/x-www-form-urlencoded',
						'Accept: application/json'
					),
				)
			);

			$token_request = curl_exec($curl);

			curl_close($curl);

			$token_request = json_decode($token_request);

			$curl = curl_init();

			curl_setopt_array(
				$curl,
				array(
					CURLOPT_URL => $url,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => '',
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 0,
					CURLOPT_SSL_VERIFYHOST => false,
					CURLOPT_SSL_VERIFYPEER => false,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => 'POST',
					CURLOPT_POSTFIELDS => '{ "amount": ' . $amount . ' }',
					CURLOPT_HTTPHEADER => array(
						'Authorization: Bearer ' . $token_request->access_token,
						'Content-Type: application/json',
					),
				)
			);

			$response = curl_exec($curl);
			
			error_log('Response Refund --> ' . $response);

			curl_close($curl);

            
			$response = json_decode($response);

			if ( isset($response->status)){
			    if( $response->status== 'Refunded' || $response->status == 'Cancelled') {
			            $order->update_meta_data('Refund_Response', $response);
			            $order->save();
			
    				return true;
    				
    			} else {
    				return new WP_Error('partial_refund_not_allowed', 'Lo sentimos, no se pudo realizar el reembolso');
    			}
    			
			} else {
			    return new WP_Error('partial_refund_not_allowed', 'Lo sentimos, no se pudo realizar el reembolso.');
			}  

		}

		public function generate_qr_form($order_id){
			global $woocommerce;
			$notification_url = get_site_url();
			$notification_url = $notification_url . '/?wc-api=getnet';
			$order = wc_get_order($order_id);
			
			$total = $order->get_total();
			error_log('Total - ' . $total);
			wc_reduce_stock_levels($order_id);
			WC()->cart->empty_cart();//BEST: No vaciar hasta un exito


			$dni = get_post_meta($order_id, 'DNI', true);
			if (empty($dni)) {
				$dni = '31313131'; //SOLICITADO POR GETNET
			}

			$total = $order->get_total();
			$total = str_replace(".", "", $total);
			$total = str_replace(",", "", $total);
			
			$total = get_adjusted_amount_total($total);
            error_log('Total despues de conversión- ' . $total);
			
			$items = $order->get_items();
			$productos = array();
			foreach ($items as $item) {

				if ($item['product_id'] > 0) {

					if ($item['variation_id'] > 0) {
						$product = wc_get_product($item['variation_id']);
					} else {
						$product = wc_get_product($item['product_id']);
					}

					if (empty($nombre)) {
						$nombre = $product->get_name();
					} else {
						$nombre = $nombre . ' - ' . $product->get_name();
					}
					
					//Revisar que los precios no tengan decimales para Argentina y Chile
					$product_price = get_adjusted_product_price($product->get_price());
					
					$productos[] = array(
						'product_type' => 'cash_carry',
						'title' => $product->get_name(),
						'description' => $product->get_name(),
						'quantity' => $item['quantity'],
						'value' => intval($product_price * $item['quantity']),
					);
				}
			}
			
			
			// Monedas aceptadas
            $accepted_currencies = array( 'ARS', 'CLP' );
        
            // Validar si la moneda actual está en la lista de aceptadas
            if ( !in_array($order->get_currency(), $accepted_currencies ) ) {
                wc_print_notice('Disculpe, sólo aceptamos pagos en pesos argentinos (ARS) y pesos chilenos (CLP).', 'error' );
                return;
            }

			$curl = curl_init();

			curl_setopt_array(
				$curl,
				array(
					CURLOPT_URL => $this->url_pago . '/authentication/oauth2/access_token',
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => '',
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 0,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => 'POST',
					CURLOPT_POSTFIELDS => 'grant_type=client_credentials&client_secret=' . $this->client_secret_id . '&client_id=' . $this->client_id,
					CURLOPT_HTTPHEADER => array(
						'Content-Type: application/x-www-form-urlencoded',
						'Accept: application/json'
					),
				)
			);

			$token_request = curl_exec($curl);
            
			curl_close($curl);

			$token_request = json_decode($token_request);

			$first_name = $order->get_billing_first_name() ? $order->get_billing_first_name() : 'María';
			$last_name = $order->get_billing_last_name() ? $order->get_billing_last_name() : 'Fernández';
			$name = trim($first_name . ' ' . $last_name);
			//$email = $order->get_billing_email() ? $order->get_billing_email() : 'john.doe@example.com';
			$phone_number = $order->get_billing_phone() ? $order->get_billing_phone() : '912345678';
			$billing_address_1 = $order->get_billing_address_1() ? $order->get_billing_address_1() : 'Providencia 1920';
			$billing_city = $order->get_billing_city() ? $order->get_billing_city() : 'Providencia';
			$billing_state = $order->get_billing_state() ? $order->get_billing_state() : 'Región Metropolitana';
			$billing_postcode = $order->get_billing_postcode() ? $order->get_billing_postcode() : '7500008';

			$post_data = array(
				"mode" => "instant",
				"payment" => array(
					"amount" => (int) $total,
					"currency" => $order->get_currency()//Leemos las monedas configuradas en la tienda
				),
				"customer" => array(
					"customer_id" => $order_id. "",
					"first_name" => $first_name,
					"last_name" => $last_name,
					"name" => $name,
					"email" => $order->get_billing_email(),
					"document_type" => "dni",
					"document_number" => $dni,
					"phone_number" => $phone_number,
					"checked_email" => true,
					"billing_address" => array(
						"street" => $billing_address_1,
						"number" => '1', // SOLICITADO POR GETNET
						"city" => $billing_city,
						"state" => $billing_state,
						"country" => $order->get_billing_country() ? $order->get_billing_country() : '', 
						"postal_code" => $billing_postcode
					),
				),
				"product" => $productos
			);

			$post_data = json_encode($post_data);

            error_log('Getnet Request payment--> ' . $post_data);

            $curl = curl_init();
            
            curl_setopt_array($curl, array(
              CURLOPT_URL => $this->url_pago . '/digital-checkout/v1/payment-intent',
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'POST',
              CURLOPT_POSTFIELDS => $post_data,
              CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Bearer ' . $token_request->access_token,
                'Accept: application/json'
              ),
            ));
            
            $response = curl_exec($curl);
            error_log('Response Getnet payment intent--> ' . $response);
            
            curl_close($curl);

			$success = $order->get_checkout_order_received_url();
			$failed = $order->get_cancel_order_url();

			$intent_id = json_decode($response);
			
			if (!$intent_id->payment_intent_id){
			    if( $intent_id->code === 'currency_not_allowed'){
    			    wc_print_notice('Moneda no soportada', error);
    			}else{
    			    wc_print_notice('Error al generar la intencion de pago', error);
    			}
			    return;
			}


			if ($this->entorno_api == 'yes') { 
			    ?>
				<script src="https://www.pre.globalgetnet.com/digital-checkout/loader.js"></script>
				<?php 
			} else { 
			    ?>
				<script src="https://www.globalgetnet.com/digital-checkout/loader.js"></script>
				<?php
			} 
			
			//Aqui vamos a meter también la validación del país
			if($this->get_option('product_type') === 'iframe' || $this->get_option('product_type') === 'lightbox'){
			    ?>
    			<div id="iframe-section" data-id="<?php echo $order_id; ?>"></div>
    
    			<script>
        			const config = {
        				"paymentIntentId": "<?php echo $intent_id->payment_intent_id; ?>",
        				"checkoutType": "<?php echo $this->get_option('product_type'); ?>",
        				"accessToken": "Bearer <?php echo $token_request->access_token; ?>"
        			};
        
        			loader.init(config);
        
        			const iframeSection = document.getElementById("iframe-section");
        			const iframe = document.querySelector('iframe[id="digital-checkout-iframe"]');
        			iframeSection.appendChild(iframe);
    			</script>
    
    			<script type="text/javascript">
    				setInterval(function () {
    
    					var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
    					var dataid = jQuery('#iframe-section').data("id");
    					jQuery.ajax({
    						type: 'POST',
    						cache: false,
    						url: ajaxurl,
    						data: {
    							action: 'revisar_pagoqrgetnet',
    							dataid: dataid
    						},
    						success: function (data, textStatus, XMLHttpRequest) {
    
    							if (data.indexOf("received") >= 0) {
    								window.location.href = data;
    							}
    
    						},
    						error: function (MLHttpRequest, textStatus, errorThrown) {
    
    						}
    					});
    
    				}, 7000);
    
    			</script>
    
    			<?php
			}
			
			$result = array('result' => 'error', 'redirect' => 'none');
			if(($this->get_option('product_type') === 'redirect')){
			    if(!$intent_id->redirect_url){
			        wc_print_notice('Error al redirigir a la pagina de pago.', error);
			        $order->update_meta_data('redirect_url', "Revisar la configuración de las llaves del comercio.");
			        
			    }else{
			        //Extraigo la URL a redirigir
    			    $order->update_meta_data('redirect_url', $intent_id->redirect_url);
    			    $order->save();
                    
                    //redirecciono al usuario a la pagina de pago
        			wp_redirect($intent_id->redirect_url);
			    }
			}

		}
		
		/**
		 * Generate Button HTML for Credential Validation
		 */
		public function generate_button_html($key, $data){
			$field = $this->plugin_id . $this->id . '_' . $key;
			$defaults = array(
				'class' => 'button-secondary',
				'css' => '',
				'custom_attributes' => array(),
				'desc_tip' => false,
				'description' => '',
				'title' => '',
			);

			$data = wp_parse_args($data, $defaults);

			ob_start();
			?>
			<tr valign="top">
				<th scope="row" class="titledesc"></th>
				<td class="forminp">
					<fieldset>
						<legend class="screen-reader-text"><span>
								<?php echo wp_kses_post($data['title']); ?></span></legend>
			<button class="<?php echo esc_attr($data['class']) . ' validate-getnet-keys'; ?>" type="button"
			name="<?php echo esc_attr($field); ?>" id="<?php echo esc_attr($field); ?>"
			style="<?php echo esc_attr($data['css']); ?>" <?php echo $this->get_custom_attribute_html($data); ?>><?php echo wp_kses_post($data['title']); ?></button>
			</fieldset>
			</td>
			</tr>
			<?php
			return ob_get_clean();
		}

		public function rudr_order_received_custom_payment_redirect() {
			// do nothing if we are not on the order received page
			if (!is_wc_endpoint_url('order-received') || empty($_GET['key'])) {
				return;
			}

			// Get the order ID
			$order_id = wc_get_order_id_by_order_key($_GET['key']);

			// Get an instance of the WC_Order object
			$order = wc_get_order($order_id);
			echo '<pre>';
			print_r($order_id);
			echo ' $order_id</pre>';
			die();
			// Now we can check what payment method was used for order
			if ('cod' === $order->get_payment_method()) {
				// if cash of delivery, redirecto to a custom thank you page
				wp_safe_redirect(site_url('/custom-page/'));
				exit; // always exit
			}
		}




        /***
         * 
         * Respuesta de getnet
         * 
         */
		public function webhook() {
			global $wpdb;
			header("HTTP/1.1 200 OK");
			
			error_log('-------Webhook-------');
			$postBody = file_get_contents("php://input");
			
			// Obtenemos todos los encabezados
            $headers = getallheaders();
        
            // Obtenemos el encabezado "Authorization"
            $authorization_header = isset($headers['Authorization']) ? $headers['Authorization'] : '';
            error_log('$authorization_header - ' . $authorization_header);
            

			$firmaAuth=  'Basic ' . base64_encode($this->webhook_user . ':' . $this->webhook_pass);
	        error_log('$firmaAuth - ' . $firmaAuth);

			
			if($authorization_header == $firmaAuth) {
			  	error_log('-----Firma Valida-----');
			  	error_log('Respuesta de Getnet Webhook-- > ' . $postBody);
			} else {
			    return;
			}
			
			$responseipn = json_decode($postBody);
			$paymentResult = $responseipn->payment->result;
			
			$formattedResult = [
				'payment_id' => $paymentResult->payment_id,
				'status' => $paymentResult->status,
				'authorization_code' => $paymentResult->authorization_code,
				'transaction_datetime' => $paymentResult->transaction_datetime
			];

			$formattedJson = json_encode($formattedResult);

			if ($responseipn->payment->result) {
				
				
				$order_id = $responseipn->customer->customer_id; //por el momento este sera el orderID
                $order = wc_get_order($order_id);
                error_log('$order_id - > ' . $order_id);
                
                $status = $order->get_status();
                error_log('$status - > ' . $status);
                
                
                if($status != 'processing'){
                    try {
                        error_log('-entro a guardado de resultado en la orden-' . $formattedJson);

    					$order->update_meta_data('Getnet_Response_Payment', $formattedJson); 	
    					$order->save();
			                

    					if ($paymentResult->status == 'Authorized') {
    					    error_log('Authorized');
    					    $order->add_order_note('GetNet: Pago Aprobado.');
    						$order->payment_complete();
    
    					} else {
    					  	error_log('no autorizado');
	                        $order->add_order_note('GetNet: Pago Rechazado.');
    					}
    					
                    } catch (Exception $e) {
                        error_log('Error al actualizar el post - ' . $e->getMessage());
                        
                    }
                }    
                   
			}
		}
	}
}






function get_adjusted_product_price($product_price) {
    //Se multiplica según los decimales para que siempre vayan "00" al final de los montos
    $decimals_aux = intval(get_option('woocommerce_price_num_decimals'));
    //print_r($product_price);
    //echo '<br>';
    switch ($decimals_aux) {
        case 1:
            $product_price *= 100;
            break;
        case 2:
            $product_price *= 100;
            break;
        case 3:
            $product_price *= 1000;
            $price_string = strval($product_price);
            $price_string = substr($price_string, 0, -1);
            $product_price = floatval($price_string);
            break;
    }
    
    return $product_price;
}

function get_adjusted_amount_total($amount_total){
    //Se ajusta según los decimales para que siempre vayan "00" al final de los montos
    $decimals = intval(get_option('woocommerce_price_num_decimals'));
	if (intval(get_option('woocommerce_price_num_decimals')) == 0) {
      $amount_total = number_format($amount_total, 2, '', '');
    }
    
    if (intval(get_option('woocommerce_price_num_decimals')) == 1) {
      $amount_total = floor($amount_total * 10);
      $amount_total = (int) $amount_total;
    }
    
    if (intval(get_option('woocommerce_price_num_decimals')) == 3) {
      $amount_total = floor($amount_total * 0.1);
      $amount_total = (int) $amount_total;
    }
    
    return $amount_total;
}

/***
 * 
 * 
 */
function enqueue_validate_getnet_keys_script(){
	?>
	<script>
		function validateGetnetKeys(form) {
		    var selectedCountry = form.elements['woocommerce_getnet_iframe_gateway_country'].value;
		    var selectedProduct = form.elements['woocommerce_getnet_iframe_gateway_product_type'].value;
		    
            var clientId = form.querySelector('#woocommerce_getnet_iframe_gateway_client_id');
			var clientSecret = form.querySelector('#woocommerce_getnet_iframe_gateway_client_secret_id');
			var check_api = form.querySelector('input[type="checkbox"][name="woocommerce_getnet_iframe_gateway_entorno_api"]:checked');
            var baseUrl = check_api ? 'https://api.pre.globalgetnet.com' : 'https://api.globalgetnet.com';
        
            if (!clientId || !clientId.value || !clientSecret || !clientSecret.value) {
                alert('Debes ingresar el Client ID y el Client Secret');
                return;
            }
        
            if (selectedCountry === 'CL' && selectedProduct === 'iframe') {
                alert('Error: Chile solo puede usar el producto "redirect" o "lightbox".');
                return;
            }
        
            /*if (selectedCountry === 'CL' && selectedProduct === 'redirect') {
                alert('Aqui va implementado el redirect chile');
                return;
            }*/
        
            jQuery.ajax({
					type: 'POST',
					url: baseUrl + '/authentication/oauth2/access_token',
					data: {
						client_id: clientId.value,
						client_secret: clientSecret.value,
						grant_type: 'client_credentials'
					},
					success: function (response) {
						if (response.access_token) {
							alert('Enhorabuena: Tus credenciales son correctas');
						} else {
							alert('Error: Tus credenciales son inválidas');
						}
					},
					error: function () {
						alert('Error: Tus credenciales son inválidas');
					}
				});
        }

		document.addEventListener('click', function (event) {
			if (event.target.classList.contains('validate-getnet-keys')) {
                const form = event.target.closest('form');
                form ? validateGetnetKeys(form) : alert('No se pudo encontrar el formulario');
            }
			
			
		});
	</script>
	<?php
}