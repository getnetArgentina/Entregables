<?php
/**
 * Plugin Name: Getnet Payment by Santander
 * Plugin URI: https://wanderlust-webdesign.com/
 * Description: Plugin que conecta la API de Getnet con WooCommerce.
 * Author: Wanderlust Codes
 * Author URI: https://wanderlust-webdesign.com/
 * Version: 0.0.3
 * Text Domain: wc-gateway-getnetIframe
 * Domain Path: /i18n/languages/
 * WC tested up to: 8.0.1
 *
 * @package   WC-Gateway-getnetIframe
 * @author    Wanderlust Codes
 * @copyright Copyright (c) 2010-2023, Wanderlust Codes
 *
 */
 

 add_action('wp_ajax_wanderlust_revisar_pagoqrgetnet', 'wanderlust_revisar_pagoqrgetnet', 1);
 add_action('wp_ajax_nopriv_wanderlust_revisar_pagoqrgetnet', 'wanderlust_revisar_pagoqrgetnet', 1);		     
 
 function wanderlust_revisar_pagoqrgetnet(){
    if($_POST['dataid']){
      $order_id = $_POST['dataid'];
      $qr_data = get_post_meta($order_id, 'qr_status', true);
      if($qr_data == 'approved'){
        $order = wc_get_order($order_id);
        $urlok =  $order->get_checkout_order_received_url();
           
        echo $urlok;
        die();
      }/*else {
          $urlok =  $order->get_cancel_order_url();
      }*/
    }
    die();       
  }

add_filter('woocommerce_payment_gateways', 'wanderlustgetnet_Iframe_add_gateway_class');
 
function wanderlustgetnet_Iframe_add_gateway_class($gateways)
{
    $gateways[] = 'WC_wanderlustGetnetIframe_Gateway';
 
    return $gateways;
}

add_action('plugins_loaded', 'wanderlustgetnet_Iframe_init_gateway_class');
 
function wanderlustgetnet_Iframe_init_gateway_class()
{
    class WC_wanderlustGetnetIframe_Gateway extends WC_Payment_Gateway
    {

        public function __construct()
        {
            define('WANDERLUST_MPQR_DIR_PATH', plugin_dir_path(__FILE__));
            define('WANDERLUST_MPQR_DIR_URL', plugin_dir_url(__FILE__));
            $this->id = 'wanderlustgetnet_iframe_gateway';
            $this->icon = apply_filters('woocommerce_wanderlustgetnet_Iframe_icon', 'https://mitcommerce.net/resources/images/LOGO_GETNET_ROJO.png');
            $this->has_fields = false;
            $this->method_title = 'Getnet LATAM';
            $this->method_description = 'Pasarela de pagos Get Checkout';
            $this->supports = array(
              'products',
              'refunds',
              'cancel'
            );
            $this->init_form_fields();
            $this->init_settings();
            //$this->title = $this->get_option('title');
            //$this->description = $this->get_option('description');
            $this->title = 'Tarjeta de crédito, débito o prepago.';
            $this->description = 'Paga seguro todo lo que necesitas con Getnet.';
            $this->billing_descriptor = $this->get_option('billing_descriptor');
            $notification_url_webhook = get_site_url();
          
          
            $this->enabled = $this->get_option('enabled');
            $this->client_id = $this->get_option('client_id');
            $this->client_secret_id = $this->get_option('client_secret_id');
            $this->entorno_api = $this->get_option('entorno_api');
            $timezone = "America/Buenos_Aires";
            date_default_timezone_set($timezone);
            $this->date_time = date('Y:m:d-H:i:s');

            if ($this->entorno_api == 'yes') {
                $this->client_id = $this->get_option('client_id');
                $this->client_secret_id = $this->get_option('client_secret_id');

                $this->url_pago = 'https://api.pre.globalgetnet.com/';
            } else {
                $this->client_id = $this->get_option('client_id');
                $this->client_secret_id = $this->get_option('client_secret_id');
                $this->url_pago = 'https://api.globalgetnet.com/';
            }
            
            // Settings
    		if ( is_admin() ) {
    			add_filter( 'woocommerce_get_settings_pages', array( $this, 'add_woocommerce_settings_tab' ) );
    			add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'action_links' ) );
    			add_action( 'woocommerce_system_status_report', array( $this, 'add_settings_to_status_report' ) );
    		}

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ));
            add_action("woocommerce_api_getnet", [$this, "webhook"]);

            add_action('woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ));
            add_action( 'template_redirect', array( $this, 'rudr_order_received_custom_payment_redirect') );

        }
        
        
        function action_links( $links ) {
    		$settings_link   = '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=wanderlustgetnet_iframe_gateway' ) . '">' . __( 'Settings', 'woocommerce' )   . '</a>';
    		$custom_links = array( $settings_link);
    		return array_merge( $custom_links, $links );
    	}
	
	

        public function init_form_fields() {

            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Habilitar/Deshabilitar',
                    'label' => 'Habilitar Getnet',
                    'type' => 'checkbox',
                    'description' => '',
                    'default' => 'no'
                ),
                /*'title' => array(
                    'title' => 'Título',
                    'type' => 'text',
                    'description' => 'Es nombre que se muestra en la opción de pagos del checkout.',
                    'default' => 'Pagar con Getnet',
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => 'Descripción',
                    'type' => 'textarea',
                    'description' => 'Es la descripción que se muestra en la opción de pagos del checkout.',
                    'default' => 'Pasarela de pagos de Getnet.',
                    'desc_tip' => true,
                ),
                'billing_descriptor' => array(
                    'title' => 'Billing Descriptor',
                    'type' => 'text',
                    'description' => 'Es la descripción que se muestra en la tarjeta.',
                    'default' => '',
                    'desc_tip' => true,
                ),*/
                'client_id' => array(
                    'title' => 'Client ID',
                    'description' => 'Es el Client ID proporcionado por Getnet a la hora de dar de alta el servicio.',
                    'type' => 'text',
                    'desc_tip' => true,
                ),
                'client_secret_id' => array(
                    'title' => 'Client Secret',
                    'description' => 'Es el Client Secret proporcionado por Getnet a la hora de dar de alta el servicio.',
                    'type' => 'text',
                    'desc_tip' => true,
                ), 
                'button_validate_keys' => array(
                  'title' => 'Validar credenciales',
                  'type' => 'button',
                  'custom_attributes' => array(),
                  'description' => '',
                  'desc_tip' => true,
                ),
                'entorno_api' => array(
                    'title' => 'Activar modo testeo',
                    'label' => 'Activar',
                    'type' => 'checkbox',
                    'description' => 'Sirve para Activar / Desactivar el modo testeo. Es para hacer pruebas con el API de pruebas de Getnet.',
                    'default' => 'no',
                    'desc_tip' => true,
                ),
				        'webhook_user' => array(
                    'title' => 'Usuario WebHook',
                    'description' => 'Ingresar usuario para WebHook',
                    'type' => 'text',
                    'desc_tip' => true,
                ),
                'webhook_pass' => array(
                    'title' => 'Password WebHook',
                    'description' => 'Ingresar password para WebHook',
                    'type' => 'text',
                    'desc_tip' => true,
                ), 
                'webhook_url' => array(
                    'title' => "Callback URL",
                    'description' => 'URL para recibir notificaciones sobre el estado final de tus transacciones',
                    'type' => 'text',
                    'desc_tip' => true,
                    'default'     => get_site_url() . '/?wc-api=getnet',
                )
            );
         

        }

        public function payment_fields() {
            if ($this->description) {

                echo wpautop(wp_kses_post($this->description));
            }
        }
      
        public function process_refund($order_id, $amount = null, $reason = '') {
            global $woocommerce;
            $order = wc_get_order($order_id);
            $total = $order->get_total();
            $url = '';
            
            /*
            if ($amount != $order->get_total()) {
                return new WP_Error('partial_refund_not_allowed', 'Solo se permite reembolsar el total del pago.');
            }*/

            $transaction_id = get_post_meta($order_id, 'getnet_response_iframe', true);
            $transaction_id = json_decode($transaction_id);

            $current_date = new WC_DateTime();

            
            $transaction_date = $transaction_id->transaction_datetime;
            $transaction_id = $transaction_id->payment_id;
            
            //update_post_meta( $order_id, "current_date original", $current_date );
            //update_post_meta( $order_id, "transaction_date original", $transaction_date );
            
            // Calcular la diferencia en horas
            $time_diff = strtotime($current_date) - strtotime($transaction_date);
            $hours_diff = $time_diff / 3600; // Convertir la diferencia a horas
            
            update_post_meta( $order_id, "hours_diff", $hours_diff );
            
            
            // Verificar si han pasado más de 24 horas
            if ($hours_diff <= 24) {
                if ($amount != $order->get_total()) {
                    return new WP_Error('partial_refund_not_allowed', 'Solo se permite cancelar el total del pago.');
                }
                // Las fechas son iguales, realizar la acción de cancelar
                $url = $this->url_pago .'checkout/v1/payments/' . $transaction_id . '/cancellation';
            } else {
                // Han pasado más de 24 horas, realizar el reembolso
                $url = $this->url_pago .'checkout/v1/payments/' . $transaction_id . '/refund';
            }

            $params = array(
                'transaction_id' => $transaction_id,
                'amount' => $amount,
            );

            $psp_Amount =  preg_replace( '#[^\d.]#', '', $amount  );
            $amount = str_replace('.', '', $psp_Amount);

            $curl = curl_init();

            curl_setopt_array($curl, array(
              CURLOPT_URL => $this->url_pago .'authentication/oauth2/access_token',
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'POST',
              CURLOPT_POSTFIELDS => 'grant_type=client_credentials&client_secret='.$this->client_secret_id.'&client_id=' .$this->client_id,
              CURLOPT_HTTPHEADER => array(
                'Content-Type: application/x-www-form-urlencoded',
                'Accept: application/json'
              ),
            ));

            $token_request = curl_exec($curl);

            curl_close($curl);
           
            $token_request = json_decode($token_request);

            $curl = curl_init();

            curl_setopt_array($curl, array(
              CURLOPT_URL => $url,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_SSL_VERIFYHOST => false,
              CURLOPT_SSL_VERIFYPEER => false,  
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'POST',
              CURLOPT_POSTFIELDS =>'{ "amount": '.$amount.' }',      
              CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer '.$token_request->access_token,
                'Content-Type: application/json',
                ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);
            
            update_post_meta($order_id, 'cancel_info', $response);
            
            $response = json_decode($response);
            if($response->status == 'Refunded'){
                return true;
            } else {
                return new WP_Error('partial_refund_not_allowed', 'No se pudo hacer el reembolso.');
            }
            
            
        }
        public function generate_qr_form($order_id) {
            
            global $woocommerce;
            $notification_url = get_site_url();
            $notification_url = $notification_url . '/?wc-api=getnet';
            $order = wc_get_order($order_id);
            $order->reduce_order_stock();
            WC()->cart->empty_cart();//TODO: No vaciar hasta un exito
            update_post_meta($order_id, 'notification', $notification_url);
            
            $dni = get_post_meta($order_id, 'DNI', true);
            if(empty($dni)){
              $dni = '31313131'; //SOLICITADO POR GETNET
            }
                       
            $total = $order->get_total();
            $total = str_replace(".","",$total);
            $total = str_replace(",","",$total);
 
            if (intval(get_option('woocommerce_price_num_decimals')) == 0) {
              $total = number_format($total, 2, '', '');
            }
			
            $items = $order->get_items();
            $productos = array();
            foreach( $items as $item ) {    	
			  
			   
 			if ( $item['product_id'] > 0 ) {
				
 				if($item['variation_id'] > 0){
				  $product = wc_get_product( $item['variation_id'] );
			  } else {
					$product = wc_get_product( $item['product_id'] );
				}
 				
                  if(empty($nombre)){
                    $nombre = $product->get_name();
                  } else {
                    $nombre = $nombre . ' - ' .$product->get_name();
                  }
                  $productos[] = array(
					           'product_type' => 'cash_carry',
                    'title' => $product->get_name(),
                    'description' => $product->get_name(),
                    'quantity' => $item['quantity'],
                    'value' => intval($product->get_price() * $item['quantity']),             
                  );
                }
          }
          $isCurrency = $order->get_currency();

          if ($isCurrency !== 'CLP') {
            //print_r('El portal solo acepta Pesos Chilenos como medio de pago');
            return;//termino la operación porque no corrresponde a la moneda
          }


            $curl = curl_init();
            
            curl_setopt_array($curl, array(
              CURLOPT_URL => $this->url_pago .'authentication/oauth2/access_token',
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'POST',
              CURLOPT_POSTFIELDS => 'grant_type=client_credentials&client_secret='.$this->client_secret_id.'&client_id=' .$this->client_id,
              CURLOPT_HTTPHEADER => array(
                'Content-Type: application/x-www-form-urlencoded',
                'Accept: application/json'
              ),
            ));

            $token_request = curl_exec($curl);

            curl_close($curl);
           
            $token_request = json_decode($token_request);
            
            $first_name = $order->get_billing_first_name() ? $order->get_billing_first_name() : 'María';
            $last_name = $order->get_billing_last_name() ? $order->get_billing_last_name() : 'Fernández';
            $name = trim($first_name . ' ' . $last_name);
            //$email = $order->get_billing_email() ? $order->get_billing_email() : 'john.doe@example.com';
            $phone_number = $order->get_billing_phone() ? $order->get_billing_phone() : '912345678';
            $billing_address_1 = $order->get_billing_address_1() ? $order->get_billing_address_1() : 'Providencia 1920';
            $billing_city = $order->get_billing_city() ? $order->get_billing_city() : 'Providencia';
            $billing_state = $order->get_billing_state() ? $order->get_billing_state() : 'Región Metropolitana';
            $billing_postcode = $order->get_billing_postcode() ? $order->get_billing_postcode() : '7500008';
            

            $post_data = array(
              "mode" => "instant",
               "seller" => array(
                  "reference"  => $order_id,
                  "mcc"  => 1000,
                  "billing_descriptor"  => $this->billing_descriptor
               ),
              
               "payment" => array(
                  "amount"  => (int)$total,
                  "currency"  => $order->get_currency()//Leemos las monedas configuradas en la tienda
               ),                   
              
               "customer" => array(
                "customer_id" => "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                "first_name" => $first_name,
                "last_name" => $last_name,
                "name" => $name,
                "email" => $order->get_billing_email(),
                "document_type" => "dni",
                "document_number" => $dni,
                "phone_number" => $phone_number,
                "checked_email" => true,
                "billing_address" => array(
                    "street" => $billing_address_1,
                    "number" => '1', // SOLICITADO POR GETNET
                    "city" => $billing_city,
                    "state" => $billing_state,
                    "country" => "AR", // SOLICITADO POR GETNET
                    //"country" => $order->get_billing_country() ? $order->get_billing_country() : '', 
                    "postal_code" => $billing_postcode
                ),
            ),
               "product" => $productos
            );
          
          
 
 
            $post_data = json_encode($post_data);

  

            $curl = curl_init();

            curl_setopt_array($curl, array(
              CURLOPT_URL => $this->url_pago . 'digital-payments/checkout/v1/payment-intent',
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'POST',
              CURLOPT_POSTFIELDS => $post_data,
              CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer '.$token_request->access_token,
                'Content-Type: application/json',
              ),
            ));
        

            $payment_intent_id = curl_exec($curl);

            curl_close($curl);
             
             $success = $order->get_checkout_order_received_url();
            $failed = $order->get_cancel_order_url();
 

            $intent_id = json_decode($payment_intent_id);
            update_post_meta($order_id, 'payment_intent_id', $intent_id->payment_intent_id );

 
           if ($this->entorno_api == 'yes') {  ?>
                <script src="https://www.pre.globalgetnet.com/digital-checkout/loader.js"></script>

            <?php } else { ?>
                <script src="https://www.globalgetnet.com/digital-checkout/loader.js"></script>
             
            <?php } ?>


  <div id="iframe-section" data-id="<?php echo $order_id;?>"></div>

  <script>
  
    const config = {
        "paymentIntentId": "<?php echo $intent_id->payment_intent_id;?>",
        "checkoutType": "lightbox",
        "accessToken": "Bearer <?php echo $token_request->access_token;?>"
      };
      
          loader.init(config);
          
          const iframeSection = document.getElementById("iframe-section");
          const iframe = document.querySelector('iframe[id="digital-checkout-iframe"]');
          iframeSection.appendChild(iframe);

        
     

 
  </script>
  
 <script type="text/javascript">		
        
         
        setInterval(function(){
          
              var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
              var dataid = jQuery('#iframe-section').data("id");
              jQuery.ajax({
                type: 'POST',
                cache: false,
                url: ajaxurl,
                data: {
                  action: 'wanderlust_revisar_pagoqrgetnet',
                  dataid: dataid
                },
                success: function(data, textStatus, XMLHttpRequest){ 

                 if (data.indexOf("received") >= 0){
					window.location.href = data;
                 }  
 
                },
                error: function(MLHttpRequest, textStatus, errorThrown){
                    
                }
              });
          
          }, 7000 );            
         



        </script>

          
<?php
        }

        /**
         * Generate Button HTML.
         */
        public function generate_button_html($key, $data)
        {
          $field = $this->plugin_id . $this->id . '_' . $key;
          $defaults = array(
            'class' => 'button-secondary',
            'css' => '',
            'custom_attributes' => array(),
            'desc_tip' => false,
            'description' => '',
            'title' => '',
          );

          $data = wp_parse_args($data, $defaults);

          ob_start();
          ?>
          <tr valign="top">
            <th scope="row" class="titledesc"></th>
            <td class="forminp">
              <fieldset>
                <legend class="screen-reader-text"><span><?php echo wp_kses_post($data['title']); ?></span></legend>
                <button class="<?php echo esc_attr($data['class']) . ' validate-getnet-keys'; ?>" type="button"
                  name="<?php echo esc_attr($field); ?>" id="<?php echo esc_attr($field); ?>"
                  style="<?php echo esc_attr($data['css']); ?>" <?php echo $this->get_custom_attribute_html($data); ?>><?php echo wp_kses_post($data['title']); ?></button>
              </fieldset>
            </td>
          </tr>
          <?php
          return ob_get_clean();
        }

        public function receipt_page($order) {
            echo $this->generate_qr_form($order);
        }

        public function process_payment($order_id) {
            $order = new WC_Order($order_id);
            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url(true)
            );
        }
      

        public function rudr_order_received_custom_payment_redirect(){

          // do nothing if we are not on the order received page
          if( ! is_wc_endpoint_url( 'order-received' ) || empty( $_GET[ 'key' ] ) ) {
            return;	
          }

          // Get the order ID
          $order_id = wc_get_order_id_by_order_key( $_GET[ 'key' ] );

          // Get an instance of the WC_Order object
          $order = wc_get_order( $order_id );
           echo '<pre>';print_r($order_id);echo' $order_id</pre>';  die();
          // Now we can check what payment method was used for order
          if( 'cod' === $order->get_payment_method() ) {
            // if cash of delivery, redirecto to a custom thank you page
            wp_safe_redirect( site_url( '/custom-page/' ) );
            exit; // always exit
          }

        }
      
       public function webhook() {
            global $wpdb;
            $log = new WC_Logger();
            header("HTTP/1.1 200 OK");
            $postBody = file_get_contents("php://input");

            $log->add("GetNet log", "return " . $postBody);

            $responseipn = json_decode($postBody);
            
            $paymentResult = $responseipn->payment->result;

            $formattedResult = [
                'payment_id' => $paymentResult->payment_id,
                'status' => $paymentResult->status,
                'authorization_code' => $paymentResult->authorization_code,
                'transaction_datetime' => $paymentResult->transaction_datetime
            ];
            
            $formattedJson = json_encode($formattedResult);
            
            
            if ($responseipn->payment_intent_id) {
                $terms = $responseipn->payment_intent_id;
                $products = $wpdb->get_results( 
                    $wpdb->prepare( "SELECT ID, post_parent FROM {$wpdb->posts} LEFT JOIN {$wpdb->postmeta} ON {$wpdb->posts}.ID = {$wpdb->postmeta}.post_id WHERE meta_key IN ( 'payment_intent_id' ) AND meta_value LIKE %s;", '%' . $wpdb->esc_like( wc_clean( $terms ) ) . '%' ) 
                    );   

                if ($products[0]->ID) {
                    $order_id = $products[0]->ID;
                    $order = wc_get_order($order_id);
                    
					update_post_meta( $order_id, "getnet_response_iframe", $formattedJson );
					update_post_meta($order_id, 'payment_id', $responseipn->payment->result->payment_id);
					update_post_meta($order_id, 'authorization_code', $responseipn->payment->result->authorization_code);
					 
					
					$status_response = $responseipn->payment->result->status;
					if( $status_response == 'Authorized'){
						
						update_post_meta($order_id, 'qr_status', 'approved');

 						update_post_meta(
                            $order_id,
                            "_getnet_response",
                            $postBody
                        );
                        $order->add_order_note(
                            "GetNet: " .
                                __("Pago Aprobado.", "wc-gateway-getnet")
                        );
                        $order->payment_complete();
						
					} else {
					    update_post_meta($order_id, 'qr_status', 'unAuthorized');
 						$order->add_order_note(
                            "GetNet: " .
                                __("Pago Fallido.", "wc-gateway-getnet")
                        );
                        update_post_meta(
                            $order_id,
                            "_getnet_response",
                            $postBody
                        );
					}
					
					
                  
                    
                }
            }
        }
      
    }
}

add_action('admin_enqueue_scripts', 'enqueue_validate_getnet_keys_script');

function enqueue_validate_getnet_keys_script()
{
  ?>
  <script>
    function validateGetnetKeys(form) {
      var clientId = form.querySelector('#woocommerce_wanderlustgetnet_iframe_gateway_client_id');
      var clientSecret = form.querySelector('#woocommerce_wanderlustgetnet_iframe_gateway_client_secret_id');
      var check_api = form.querySelector('input[type="checkbox"][name="woocommerce_wanderlustgetnet_iframe_gateway_entorno_api"]:checked');
      var entorno_api = 'https://api.globalgetnet.com';
      
      if(check_api){
          entorno_api = 'https://api.pre.globalgetnet.com';
      }
        

      if (clientId && clientId.value && clientSecret && clientSecret.value) {
        jQuery.ajax({
          type: 'POST',
          url: entorno_api + '/authentication/oauth2/access_token',
          data: {
            client_id: clientId.value,
            client_secret: clientSecret.value,
            grant_type: 'client_credentials'
          },
          success: function (response) {
            if (response.access_token) {
              alert('Enhorabuena: Tus credenciales son correctas');
            } else {
              alert('Error: Tus credenciales son inválidas');
            }
          },
          error: function () {
            alert('Error: Tus credenciales son inválidas');
          }
        });
      } else {
        alert('Debes ingresar el Client ID y el Client Secret');
      }
    }

    document.addEventListener('click', function (event) {
      if (event.target.classList.contains('validate-getnet-keys')) {
        var form = event.target.closest('form');
        if (form) {
          validateGetnetKeys(form);
        } else {
          alert('No se pudo encontrar el formulario');
        }
      }
    });
  </script>
  <?php
}