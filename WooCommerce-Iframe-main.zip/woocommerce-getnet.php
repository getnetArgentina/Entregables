<?php
/**
 * Plugin Name: Getnet Payment by Santander
 * Plugin URI: https://www.getnet.com.ar/
 * Description: Plugin que conecta la API de Getnet con WooCommerce.
 * Author: MIT
 * Author URI: https://www.getnet.com.ar/
 * Version: 0.1.0
 * Text Domain: wc-gateway-getnetIframe
 * Domain Path: /i18n/languages/
 * WC tested up to: 8.0.1
 *
 * @package   WC-Gateway-getnetIframe
 * @author    MIT
 * @copyright Copyright (c) 2024, Mercadotecnia Ideas y tecnología.
 *
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Incluir la lógica de WooCommerce.
require_once __DIR__ . '/includes/getnet-logic.php';

// Verificar que WooCommerce esté activo.
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    error_log('Woocommerce is not active, so the WC_GetnetIframe_Gateway plugin is not running correctly');
    return;
}

// Añadir la clase de pasarela de pago.
add_filter('woocommerce_payment_gateways', 'getnet_iframe_add_gateway_class');
function getnet_iframe_add_gateway_class($gateways) {
    $gateways[] = 'WC_GetnetIframe_Gateway';
    return $gateways;
}



// Settings
if (is_admin()) {
	add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'action_links');
}

function action_links($links)
{
	$settings_link = '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=getnet_iframe_gateway') . '">' . __('Settings', 'woocommerce') . '</a>';
	$custom_links = array($settings_link);
	return array_merge($custom_links, $links);
}

add_action('plugins_loaded', 'getnet_Iframe_init_gateway_class');
add_action('admin_enqueue_scripts', 'enqueue_validate_getnet_keys_script');

function enqueue_my_custom_scripts() {
    wp_enqueue_script('utils-getnet', plugin_dir_url(__FILE__) . 'assets/js/utils_getnet.js', array('jquery'), null, true);
    
    wp_localize_script('utils-getnet', 'siteData', array(
        'siteUrl' => get_site_url()
    ));
    
    wp_localize_script('utils-getnet', 'wpApiSettings', array(
        'nonce' => wp_create_nonce('wp_rest')
    ));

}
add_action('wp_enqueue_scripts', 'enqueue_my_custom_scripts');



/**
 * Custom function to declare compatibility with cart_checkout_blocks feature
 */
function declare_cart_checkout_blocks_compatibility() {
    // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        // Declare compatibility for 'cart_checkout_blocks'
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
    
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
    }
}


// Hook the custom function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'declare_cart_checkout_blocks_compatibility');

// Hook the custom function to the 'woocommerce_blocks_loaded' action
add_action( 'woocommerce_blocks_loaded', 'oawoo_register_order_approval_payment_method_type' );




/**
 * Custom function to register a payment method type
 */
function oawoo_register_order_approval_payment_method_type() {
    // Check if the required class exists
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }
    // Include the custom Blocks Checkout class
    require_once plugin_dir_path(__FILE__) . 'class-block.php';
    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
            // Register an instance of WC_GetnetIframe_Gateway_Blocks
            $payment_method_registry->register( new WC_GetnetIframe_Gateway_Blocks );
        }
        );
}